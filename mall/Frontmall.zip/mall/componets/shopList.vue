<template>
		<view class="shopList">
			<view class="shopListItem"  v-for="(item,index) in catess" :key="index">
				<navigator hover-class="none" :url="'../detail/detail?id='+item.id">
					<image class="shopImg" :src="imgUrl+item.mainimage" mode=""></image>
					<view class="shopTitle">
						{{item.smalltitle}}
					</view>
					<view class="shopActive">
						<view class="shopActiveLab" v-if="item.tag==1">
							新品
						</view>
						<view class="shopActiveLab" v-else-if="item.tag==2">
							促销
						</view>
						<view class="shopActiveLab" v-else>
							热销
						</view>
						<view class="shopActiveTxt">
							{{item.summary}}
						</view>
					</view>
					<view class="shopPrice">
						¥{{item.price}}
					</view>
				</navigator>
			</view>
		</view> 
</template>

<script>
	export default {
		props:['catess']
	}
</script>

<style>
	.shopList {
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
	}
	.shopListItem {
		width: 370rpx;
		height: 540rpx;
		background-color: #fff;
		overflow: hidden;
		margin-top: 10rpx;
	}
	
	.shopListItem .shopImg {
		width: 316rpx;
		height: 316rpx;
		display: block;
		margin: 40rpx auto 0;
	}
	
	.shopListItem .shopTitle {
		text-align: center;
		height: 50rpx;
		font-size: 28rpx;
		line-height: 50rpx;
	}
	
	.shopListItem .shopActive {
		height: 40rpx;
		width: 346rpx;
		border: 1rpx solid #d9000b;
		margin: 0 auto;
		display: flex;
	}
	
	.shopActive .shopActiveLab {
		width: 70rpx;
		font-size: 24rpx;
		color: #fff;
		height: 100%;
		background-color: #d9000b;
		text-align: center;
		line-height: 40rpx;
		margin-right: 10rpx;
	}
	
	.shopActive .shopActiveTxt {
		width: 276rpx;
		font-size: 24rpx;
		color: #d9000b;
		/* 单行显示省略号 */
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		/* 单行显示省略号 */
		line-height: 40rpx;
	}
	
	.shopPrice {
		font-size: 28rpx;
		color: #d9000b;
		line-height: 80rpx;
		text-align: center;
	}
</style>
