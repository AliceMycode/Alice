<template>
	<view class="floorTable">
		<view class="tableItem">
			<image :src="imgUrl+tables[0].img" mode=""></image>
		</view>
		<view class="tableItem" style="background: #7064ca;">
			<view class="tableBigTitle">
				{{tables[0].name}}
			</view>
			<view class="tableSmallTitle">
				{{tables[0].summary}}
			</view>
			<view class="tableLine">
				
			</view>
			<view class="tablePrice">
				¥{{tables[0].price}}
			</view>
		</view>
		<view class="tableItem" style="background: #f65c5c;">
			<view class="tableBigTitle">
				{{tables[1].name}}
			</view>
			<view class="tableSmallTitle">
				{{tables[1].summary}}
			</view>
			<view class="tableLine">
				
			</view>
			<view class="tablePrice">
				¥{{tables[1].price}}
			</view>
		</view>
		<view class="tableItem">
			<image :src="imgUrl+tables[1].img" mode=""></image>
		</view>
	</view>
</template>

<script>
	export default {
		props:['tables']
	}
</script>

<style>
	.floorTable {
		display: flex;
		flex-wrap: wrap;
	}
	.floorTable .tableItem {
		width: 50%;
		height: 330rpx;
	}
	.floorTable .tableItem image {
		width: 100%;
		height: 330rpx;
	}
	.tableBigTitle {
		font-size: 30rpx;
		color: #fff;
		line-height: 46rpx;
		padding: 30rpx 120rpx 0 30rpx;
	}
	.tableSmallTitle {
		font-size: 20rpx;
		color: rgba(255,255,255,.8);
		line-height: 30rpx;
		padding: 0 40rpx 0 30rpx;
		padding-top: 15rpx;
		/* d多行显示省略号 */
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp:2;
		-webkit-box-orient:vertical;
		/* d多行显示省略号 */
	}
	.tableLine {
		height: 10rpx;
		width: 35rpx;
		background-color: #fff;
		margin-top: 25rpx;
		margin-left: 30rpx;
		border-radius: 5rpx;
	}
	.tablePrice {
		font-size: 40rpx;
		color: rgba(255,255,255,.8);
		line-height: 100rpx;
		margin-left: 30rpx;
	}
</style>
