<template>
	<view class="IndexAdBox">
		<view class="IndexAd">
			<view class="IndexAdLeft">
				<view v-if="ads.length>0">
					<image :src="imgUrl+ads[0].image" mode=""></image>
				</view>
			</view>
			<view class="IndexAdRigth">
				<view class="IndexAdRigthItem" v-if="ads.length>0">
					<navigator url="#" hover-class="none">
						<image :src="imgUrl+ads[1].image" mode=""></image>
					</navigator>
				</view>
				<view class="IndexAdRigthItem">
					<navigator url="#" hover-class="none" v-if="ads.length>0">
						<image :src="imgUrl+ads[2].image" mode=""></image>
					</navigator>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props:['ads'],
		//不兼容时使用这条代码
		// data(){
		// 	return {
		// 		imgUrl:this.$imgUrl
		// 	}
		// }
	}
</script>

<style>
	.IndexAd{
		  display: flex;
		 border-top: 20rpx solid #f4f4f4;
	  }
	  .IndexAdLeft{
		  width: 50%;
		  height: 520rpx;
	  }
	  .IndexAdLeft image {
		  width: 100%;
		   height: 520rpx;
	  }
	.IndexAdRigth {
		width: 50%;
	}
	.IndexAdRigthItem {
		height: 260rpx;
	}
	  .IndexAdRigthItem image {
		  height: 260rpx;
		  width: 100%;
	  }
</style>
