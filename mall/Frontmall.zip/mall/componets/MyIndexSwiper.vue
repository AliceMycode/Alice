<template>
	<view class="">
		<swiper class="swiper" :style="{height:swiperHeight}"
		:indicator-dots="true" 
		:autoplay="true" 
		:interval="3000" 
		:duration="1000"
		:circular="true"
		indicator-color="#7d7c82"
		:indicator-active-color="swiperActive"
		>
			<swiper-item v-for="(item,index) in swiper" :key="index">
				<view class="swiper-item">
					<navigator url="#" hover-class="none">
						<image :src="imgUrl+item.image" mode="" :style="{width:width,height:height}"></image>
					</navigator>
				</view>
			</swiper-item>
			<!-- <swiper-item>
				<view class="swiper-item">
					<image src="../static/image/banner2.jpg" mode=""></image>
				</view>
			</swiper-item>
			<swiper-item>
				<view class="swiper-item">
					<image src="../static/image/banner3.jpg" mode=""></image>
				</view>
			</swiper-item>
			<swiper-item>
				<view class="swiper-item">
					<image src="../static/image/banner4.jpg" mode=""></image>
				</view>
			</swiper-item> -->
		</swiper>
	</view>
</template>

<script>
	export default {
		props:['swiper','swiperHeight','swiperActive','width','height']
	}
</script>

<style>
	/* 已经通过父子传输数据的方式将图片的宽、和高传给子组件了所以这里的宽和高已经不起作用来了，所以下面两个样式已经失效了 */
	.swiper image {
			 /* width: 100%;
			  height: 390rpx; */
			  display: block;
			  margin: 0 auto;
	}
	.swiper {
		/* height: 390rpx; */
	}
</style>
