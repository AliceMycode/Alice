<template>
	<view>
		<view class="status_bar"></view>
		<view class="header">
			<!-- 导航栏 -->
				<view class="navbar">
					<view class="search">
						<image src="../static/image/search.png" mode=""></image>
					</view>
					<view class="logo">
						<image src="../static/image/logo.png" mode=""></image>
					</view>
					<view class="cart">
						<image src="../static/image/trolley.png" mode=""></image>
					</view>
				</view>
			<!-- 菜单栏 -->
				<view class="menuTab">
					<view class="menuTabItem menuActive">推荐</view>
					<view class="menuTabItem" v-for="(item,index) in recommend" :key="index">{{item.catename}}</view>
					<!-- <view class="menuTabItem">声学</view>
					<view class="menuTabItem">配件</view>
					<view class="menuTabItem">生活</view> -->
				</view>
		</view>
		<view class="headerEmpty"></view>
	</view>
</template>
	
<script>
	export default {
		props:['recommend']
	}
</script>

<style>
	.status_bar {
			  height: var(--status-bar-height);
			  width: 100%;
			  background-color: #f4f4f4;
	 }
	.header {
			  height: 180rpx;
			  position: fixed;
			  z-index: 10;
			  width: 100%;
			  /* 解决首页轮播图被header吃掉一部分的问题 */
			 /* top:  var(--status-bar-height); */
			  top:0;
			  padding-top: var(--status-bar-height);
			  /* top:0,padding-top: var(--status-bar-height);*/
			  background-color: #fff;
	}
	.navbar{
			  height: 110rpx;
			  display: flex;
			  margin: 0 20rpx;
			  align-items: center;
			  justify-content: space-between;
	}
	.navbar .search image,.navbar .cart image{
			  width: 30rpx;
			  height: 30rpx;
	}
	.navbar .logo image{
			  width: 140rpx;
			  height: 30rpx;
	}
	.menuTab {
			  height: 70rpx;
			  margin: 0 20rpx;
			  display: flex;
			  justify-content: space-between;
	}
	.menuTabItem {
			  font-size: 28rpx;
			  color: #000;
			  width: 60rpx;
			  height: 55rpx;
			  line-height: 55rpx;
	}
	.menuTab .menuTabItem.menuActive {
			  color: #0bbbef;
			  border-bottom: 1rpx solid #0bbbef;
	}
	.headerEmpty {
			  height: 180rpx;
	}
</style>
