<template>
	<view class="">
		<!-- 服务弹窗 -->
		<view class="service">
			<view class="bg"></view>
			<view class="serviceContent">
				<view class="serviceContentTitle">
					服务说明<i class="iconfont"  @click="closeBtn">&#xe62b;</i>
				</view>
				<view class="serviceList">
					<view class="serviceItem"
					v-for="(item,index) in content"
					:key="index"
					>
						<view class="serviceItemTitle">
							<!-- <i class="iconfont">&#xe8af;</i> -->
							<image :src="imgUrl+item.image" mode=""></image>
							<text>{{item.title}}</text>
						</view>
						<view class="serviceItemContent">
							{{item.summary}}
						</view>
					</view>
				</view>
			</view>
			<view class="serviceBottom"  @click="closeBtn">确认</view>
		</view>
	</view>
</template>

<script>
	export default {
		props:['content'],
		data(){
			return {
				
			}
		},
		methods:{
			closeBtn(){
				this.$emit('closeItem')
			}
		}
	}	
</script>

<style>
	.service {
		position: fixed;
		top: 0;
		bottom: 0;
		left: 0;
		right: 0;
	}
	.bg {
		position: fixed;
		top: 0;
		bottom: 0;
		left: 0;
		right: 0;
		background-color: rgba(0,0,0,.3);
	}
	.serviceContent {
		position: absolute;
		height: 1000rpx;
		right: 0;
		letter-spacing: 0;
		bottom: 0;
		background-color: #fff;
		width: 100%;
	}
	.serviceContent .serviceContentTitle {
		height: 120rpx;
		line-height: 120rpx;
		font-size: 40rpx;
		font-weight: 700;
		text-align: center;
		position: relative;
	}
	.serviceContent .serviceContentTitle i {
		position: absolute;
		top: 45rpx;
		right: 20rpx;
		line-height: 40rpx;
	}
	.serviceItem {
		border-bottom: 1rpx solid #e7e7e7;
		padding-bottom: 35rpx;
	}
	.serviceItemTitle {
		line-height: 60rpx;
		display: flex;
		align-items: center;
	}
	/* .serviceItemTitle i {
		margin-left: 20rpx;
		margin-right: 10rpx;
		color: #95e1df;
	} */
	.serviceItemTitle image {
		width: 30rpx;
		height: 30rpx;
		margin-left: 20rpx;
		margin-right: 10rpx;
	}
	.serviceItemTitle text {
		font-size: 30rpx;
		color: #000;
	}
	.serviceItemContent {
		color: #999;
		font-size: 30rpx;
		line-height: 40rpx;
		padding: 0 50rpx;
	}
	.serviceBottom {
		width: 100%;
		font-size: 40rpx;
		color: #fff;
		background-color: #00c3f5;
		text-align: center;
		position: fixed;
		bottom: 0;
		font-weight: 700;
		letter-spacing: 2rpx;
		line-height: 90rpx;
		height: 90rpx;
	}
</style>
