<template>
			<view class="floorTitle">
				<view class="title">
					{{name}}
				</view>
				<view class="line">
					
				</view>
			</view>
</template>

<script>
	export default {
		props:{
			name:String
		}
	}
</script>

<style>
	.floorTitle {
		height: 180rpx;
	}
	.floorTitle .title {
		line-height: 90rpx;
		font-size: 36rpx;
		font-weight: bolder;
		padding-top: 35rpx;
		color: #000;
		text-align: center;
	}
	.floorTitle .line {
		width: 45rpx;
		height: 6rpx;
		margin: 0 auto;
		background-color: #07baf2;
	}
</style>
