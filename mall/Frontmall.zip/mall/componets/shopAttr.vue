<template>
	<view class="">
		<!-- 商品规格选择 -->
		<view class="attrDialog">
			<view class="bg"></view>
			<view class="attrDialogContent">
				<view class="contentTop">
					<view class="contentTopImg">
						<image :src="imgUrl+image" mode=""></image>
					</view>
					<view class="contentTopTxt">
						<text class="price">¥ {{currentPrice}}</text>
						<text class="attr">{{checkVal}}</text>
					</view>
					<i class="iconfont" @click="close">&#xe62b;</i>
				</view>
				<view class="attrList">
					<view class="attrItem" v-for="(Item,index) in checkAttr" :key="index">
						<view class="attrItemTitle">
							{{Item.attrname}}
						</view>
						<view class="attrItemVal">
							<!-- activeAttr -->
							<view class="attrValItem" 
							v-for="(child,childIndex) in Item.value" 
							:key="childIndex"
							:class="{activeAttr:valIndex[index]==childIndex}"
							@click="attrCheck(index,childIndex)"
							>
								{{child}}
							</view>
						</view>
					</view>
					<view class="attrItem">
						<view class="attrItemTitle">
							数量
						</view>
						<view class="attrItemVal">
							<view class="shopNum">
								<view class="Button" @click="reduce">-</view>
								<view class="">
									<!-- <input type="text" value="1" /> -->
									<!-- <input  disabled=disabled type="text" v-model="num"/> -->
									<!-- <input  readonly="readonly" type="text" v-model="num"/> -->
									 <input class="input" type="text" v-model="num"/>
								</view>
								<view class="Button" @click="add">+</view>
							</view>
							<text class="stock">(库存：{{stock}}件)</text>
						</view>
					</view>
				</view>
			</view>
			<view class="BottomButton" @click="attrBtn">
				{{buttonTxt}}
			</view>
		</view>
	</view>
</template>

<script>
	export default {
			props:['image','attr','price','checkAttr','type'],
			data(){
				return {
					valIndex:[],//动态生成数组用于激活状态显示
					checkVal:'',//显示价格下面的商品的属性
					currentPrice:'',//选好商品属性之后对应的价格默认为空
					stock:'',//商品库存信息
					num:1,//商品数量
					buttonTxt:'',//底部按钮文本,
					attrid:''
				}
			},
			mounted(){
				//用户在商品属性页选择完自己想要都商品属性时再次关闭商品属性页然后再打开商品属性页；
				//发现商品属性都默认选择各个属性都第一个属性值而没有把用户自己选择都商品属性保存下来；
				//原因是因为下面这个for循环把引用类型数组重新赋值；
				//为了解决这个问题需要把用户选择的商品属性值保存下来并在商品规格尺寸栏显示
			/******************************************************************/
				if(this.$store.state.attrVal.length==0){
					for(var i=0;i<this.checkAttr.length;i++){
						this.valIndex.push(0);
					}
				}else{
					this.valIndex = this.$store.state.attrVal;
				}
			/******************************************************************/	
				//价格下面的商品文本信息
				this.checkVal = this.getval().toString()
				//对应商品价格
				this.getPrice(this.getval())
				//console.log(this.attr)
				if(this.type==1){
					this.buttonTxt = "立即购买"
				}else{
					this.buttonTxt = "加入购物车"
				}
				
			},
			methods:{
				//点击购物车或立即购买跳转处理
				attrBtn(){
					if(this.type==1){
						//1、把当前选择的商品的数量、id保存起来
						var orderShop = [{"num":this.num,"attrid":this.attrid}]
						//2、转化为字符串然后存到本地缓存，然后在订单页面作为参数发请求渲染订单列表
						uni.setStorageSync('ordershop',JSON.stringify(orderShop))
						this.$back('../order/order',1)//1表示普通页面跳转
					}else{
						//将用户选择的商品保存导数据库
						this.$request('member/addcart',{
							"num":this.num,
							"attrid":this.attrid
						}).then(res=>{
							uni.showToast({
								title:"加入购物车成功",
								icon:"none"
							})
						})
						this.$back('../cart/cart',2)//2表示tabbar页面跳转
					}
				},
				//减少
				reduce(){
					if(this.num==1)
					return
					this.num--;
				},
				//增加
				add(){
					//num、和stock数据类型同为字符串字符串之间的对比不能用大于小于
					if(parseInt(this.num)>=parseInt(this.stock))
					return
					this.num++
				},
				//关闭商品属性选择弹窗事件
				close(){
					this.$emit('closeEvent')
					console.log(this.valIndex,this.checkVal)
					//关系商品属性选择也是保存用户的所选择的商品属性值
				/******************************************************************/
					this.$store.commit('setAttr',{
						"attrVal":this.valIndex,
						"attrTxt":this.checkVal
					})
				/******************************************************************/
				},
				//获取当前商品价格已经激活状态选择
				attrCheck(index,childIndex){
					//1、根据我们的逻辑此条代是可以满足激活状态切换的但是数组元素变了但是状态没有变，
					//2、出现这情况是因为数组类型为引用类型，表面上是改变了数组元素但实质上没有变
					//3、引用类型数组不能直接这样赋值this.valIndex[index] = childIndex;
					this.valIndex.splice(index,1,childIndex)
					//用户选择的商品属性
					var valCheck = this.getval();
					//转化为字符串显示在价格下面
					this.checkVal = valCheck.toString();
					this.getPrice(valCheck);
					//console.log(this.valIndex)
					// console.log(index,childIndex)
					//记录用户点下的商品属性
					// var temp=[];
					// for(var i=0;i<this.checkAttr.length;i++){
					// 	for(var j=0;j<this.checkAttr[i].value.length;j++){
					// 		temp.push(this.checkAttr[i].value[this.valIndex[i]])
					// 		break;
					// 	}
					// }
					//console.log(this.getval())
				},
				//获取当前商品价格子函数
				getPrice(valCheck){
					var temp = [];
					for(var i=0;i<this.attr.length;i++){
						if(this.attr[i]['attr_0']==valCheck[0]&&this.attr[i]['attr_1']==valCheck[1]){
							temp.push(this.attr[i])
						}
					}
					//商品价格
					this.currentPrice = temp[0].price;
					//商品库存
					this.stock = temp[0].stock;
					//商品id
					this.attrid=temp[0].id
					//console.log(temp);
				},
				//记录用户点下的商品属性
				getval(){
					var temp=[];
					for(var i=0;i<this.checkAttr.length;i++){
						for(var j=0;j<this.checkAttr[i].value.length;j++){
							temp.push(this.checkAttr[i].value[this.valIndex[i]])
							break;
						}
					}
					return temp
				}
			}
	}
</script>

<style>
	.attrDialog {
		position: fixed;
		left: 0;
		right: 0;
		top: 0;
		bottom: 0;
	}
	.attrDialog .bg {
		width: 100%;
		height: 100%;
		background-color: rgba(0,0,0,.4);
	}
	.attrDialogContent {
		height: 1070rpx;
		width: 100%;
		position: absolute;
		bottom: 0;
		background-color: #fff;
	}
	.contentTop {
		position: relative;
		height: 200rpx;
		width: 100%;
	}
	.contentTop  image {
		width: 100%;
		height: 100%;
	}
	.contentTopImg {
		position: absolute;
		width: 210rpx;
		height: 210rpx;
		left: 30rpx;
		top: -40rpx;
		border: 3rpx solid #00C3F5;
		background-color: #fff;
	}
	.contentTopTxt {
		margin-left: 280rpx;
	}
	.contentTopTxt .price {
		height: 45rpx;
		font-size: 36rpx;
		color: #f0415f;
		line-height: 45rpx;
		padding-top: 25rpx;
		display: block;
		font-weight: 700;
	}
	.contentTopTxt .attr {
		font-size: 24rpx;
		color: #000;
		line-height: 45rpx;
		height: 40rpx;
		font-weight: 400;
	}
	.contentTop i {
		position: absolute;
		top: 25rpx;
		right: 30rpx;
		width: 80rpx;
		height: 90rpx;
		line-height: 90rpx;
		text-align: center;
	}
	/* 清除浮动带来的影响 */
	.attrItem {
		height: auto;
		overflow: hidden;
	}
	/* 清除浮动带来的影响 */
	.attrList {
		padding: 0 30rpx;
	}
	.attrItemTitle {
		color: #999;
		font-size: 30rpx;
		line-height: 70rpx;
	}
	.attrValItem {
		padding: 0 30rpx;
		border: 1rpx solid #00C3F5;
		line-height: 70rpx;
		height: 70rpx;
		float: left;
		color: #666;
		font-size: 30rpx;
		margin-right: 30rpx;
	}
	.attrValItem.activeAttr {
		color: #00C3F5;
		border: 1rpx solid #00C3F5;
	}
	.shopNum {
		width: 240rpx;
		height: 70rpx;
		display: flex;
		border: 1rpx solid #E5E5E5;
		float: left;
	}
	.shopNum .Button {
		width: 70rpx;
		line-height: 70rpx;
		text-align: center;
	}
	.shopNum input {
		width: 100rpx;
		height: 70rpx;
		border-left: 1rpx solid #E5E5E5;
		border-right: 1rpx solid #E5E5E5;
		line-height: 70rpx;
		text-align: center;
		font-size: 24rpx;
	}
	.stock {
		line-height: 70rpx;
		height: 70rpx;
		color: #999;
		font-size: 24rpx;
		margin-left: 20rpx;
	}
	.BottomButton {
		height: 90rpx;
		line-height: 90rpx;
		font-size: 40rpx;
		font-weight: 700;
		letter-spacing: 2rpx;
		color: #fff;
		background-color: #0EBCEF;
		position: absolute;
		bottom: 0;
		width: 100%;
		text-align: center;
	}
	.input {
		 pointer-events: none;
	}
</style>
