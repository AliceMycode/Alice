<template>
	<view class="">
		<view class="service">
			<view class="serviceItem" v-for="(item,index) in actives" :key="index">
				<image :src="imgUrl+item.image" mode=""></image>
				<text>{{item.title}}</text>
			</view>
			<!-- <view class="serviceItem">
				<image src="../static/image/icon2.png" mode=""></image>
				<text>满80免运费</text>
			</view>
			<view class="serviceItem">
				<image src="../static/image/icon3.png" mode=""></image>
				<text>7天无理由退货</text>
			</view> -->
		</view>
		<view class="shopNav">
			<view class="shopNavItem" v-for="(item,index) in icons" :key="index">
				<navigator url="#" hover-class="none">
					<image :src="imgUrl+item.image" mode=""></image>
				</navigator>
					<text>{{item.title}}</text>
			</view>
		<!-- 	<view class="shopNavItem">
				<image src="../static/image/recommend2.png" mode=""></image>
				<text>魅族 16S</text>
			</view>
			<view class="shopNavItem">
				<image src="../static/image/recommend3.jpg" mode=""></image>
				<text>魅族 Note9</text>
			</view>
			<view class="shopNavItem">
				<image src="../static/image/recommend4.jpg" mode=""></image>
				<text>以旧换新</text>
			</view> -->
		</view>
	</view>
</template>

<script>
	export default {
		props:['actives','icons']
	}
</script>

<style>
	.service image {
			  width: 35rpx;
			  height: 35rpx;
			  margin:0 10rpx
	}
	.service {
			  display: flex;
			  height: 70rpx;
			  align-items: center;
			  background-color: #f7f7f7;
			  justify-content: space-around;
	}
	.serviceItem{
			  display: flex;
			  align-items: center;
	}
	.serviceItem text {
			  font-size: 24rpx;
			  color: #a3a3a3;
			  display: flex;
	}
	.shopNav{
			  height: 225rpx;
			  display: flex;
			  justify-content: space-between;
			  background-color: #fff;
			  
	}
	.shopNav image {
			  width: 100rpx;
			  height: 100rpx;
			  margin: 30rpx;
	}
	.shopNav .shopNavItem text {
			  font-size: 24rpx;
			  color: #000;

	}
	.shopNav .shopNavItem {
			  display: flex;
			  flex-direction: column;
			  align-items: center;
	}
</style>
