//导入两个插件，不需要重新安装，Hbuilder内置了
/******************************************************************/
import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
	const store = new Vuex.Store({
		state:{
			attrVal:[],//shopAttr里的valIndex[]
			attrTxt:'请选择商品规格尺寸',//,
			isLogin:0//0表示未登陆
		},
		mutations:{
			//设置商品属性
			setAttr(state,data){
				state.attrVal = data.attrVal;
				state.attrTxt = data.attrTxt;
			},
			//商品默认属性
			defaultAttr(state){
				state.attrVal = [],
				state.attrTxt='请选择商品规格尺寸'
			},
			//登陆场操作
			login(state){
				state.isLogin=1
			},
			//退出操作
			loginout(state){
				state.isLogin=0;
				uni.setStorageSync('token','')
			}
		}
	})

export default store; 
/******************************************************************/