import App from './App'




import store from './store/index.js'//用来保存用户选择商品属性用的，
import check from './check/index.js'//手机号/密码/验证码/用户名/收货地址/详细收货地址验证用的
// #ifndef VUE3
import Vue from 'vue'
Vue.config.productionTip = false
Vue.prototype.imgUrl = "http://www.mall.com/uploads/"//统一图片路径
Vue.prototype.apiUrl = "http://www.mall.com/api/"//统一请求路径
Vue.prototype.check = check//统一验证格式
//统一请求格式,函数类型为function，this拿不到数据，此时两种解决方法1、定义that；2、箭头函数
Vue.prototype.$request = function(url,data=""){
	return new Promise((reslove,reject)=>{
		//var that = this
			uni.request({
				url:this.apiUrl+url,
				method:"POST",
				header:{
					'token':uni.getStorageSync('token')
				},
				data:data,
				success:res=>{
					//未登陆先登陆
					if(res.data.tcode==0){
						//this.tcode=0
						reslove({"tcode":0,"msg":"请先登陆"})
					}
					//已经登陆
					if(res.data.tcode==1){
						//this.tcode=1
						//this.member=res.data.data;
						reslove(res.data)
					}
					//token过期（5分钟失效）需重新用新返回的token替换原来的token，并用新的token重新发请求
					if(res.data.tcode==2){
						uni.setStorageSync('token',res.data.token)
						uni.request({
							url:this.apiUrl+url,
							method:"POST",
							header:{'token':uni.getStorageSync('token')},
							data:data,
							success:res=>{
								//this.tcode=1
								//this.member=res.data.data;
								reslove(res.data)
							}
						})
					}
					//若token失效,需重新登陆(防伪造)
					if(res.data.tcode==3){
						//this.tcode=0;
						reslove({"code":3,"msg":"token失效,请重新登陆"})
						uni.setStorageSync('token','')
					}
					//token有效未过期，但没有相关用户
					if(res.data.tcode==4){
						//this.tcode=0;
						reslove({"code":4,"msg":"token有效未过期，但没有相关用户"})
						uni.setStorageSync('token','')
					}
					//code==0或不存在就抛出整块数据
					if(res.data.code==0||res.data.code){
						reslove(res.data)
					}
				}
			})
		})
	}
//个人中心统一跳转处理
//身份验证跳转
Vue.prototype.$href=function(data,type){
	if(uni.getStorageSync('token')){
		//普通页面之间的跳转
		if(type==1){
			uni.navigateTo({
				url:data
			})
		}
		//tabbar页面跳转
		if(type==2){
			uni.switchTab({
				url:data
			})
		}
	}else{
		uni.navigateTo({
			url:'/pages/login/login?backurl='+data
		})
	}
}
//购物车&&立即购买页面跳转处理
Vue.prototype.$back=function(data,type){
	if(uni.getStorageSync('token')){
		//普通页面之间的跳转
		if(type==1){
			uni.navigateTo({
				url:data
			})
		}
		//tabbar页面跳转
		if(type==2){
			uni.switchTab({
				url:data
			})
		}
	}else{
		uni.navigateTo({
			url:'/pages/login/login?backurl=1'
		})
	}
}




App.mpType = 'app'
const app = new Vue({
	store,//相当于组件注册
    ...App
})
app.$mount()
// #endif

// #ifdef VUE3
import { createSSRApp } from 'vue'
export function createApp() {
  const app = createSSRApp(App)
  return {
    app
  }
}
// #endif