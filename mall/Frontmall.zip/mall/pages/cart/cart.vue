<template>
	<view v-if="show">
		<!-- 购物车无内容时显示 -->
		<view v-if="isLogin==0">
			<image src="../../static/image/cartEmpty.png" mode="" class="cartEmpty"></image>
			<view class="cartEmptyTip">亲，您需要登陆才能查看购物车哟～</view>
			<navigator url="../login/login?backurl=1">
				<view class="cartLogin">立即登陆</view>
			</navigator>
		</view>
		<!-- 购物车列表开始 -->
		<view v-else>
			<view v-if="cartList.length==0">
				<image src="../../static/image/cartEmpty.png" mode="" class="cartEmpty"></image>
				<view class="cartEmptyTip">亲，您的购物车空空如也哟～</view>
			</view>
			<view class="cartBox" v-else>
				<view class="cartLists">
					<uni-swipe-action>
						<uni-swipe-action-item :right-options="options"
						v-for="(item,index) in cartList" 
						:key="index" 
						@click="delBtn($event,item.id,index)">
							<view class="cartItem">
								<label @click="changeBox(index)">
									<image src="../../static/image/checkbox1.png" mode="" v-if="item.flag"></image>
									<image src="../../static/image/checkbox.png" mode="" v-else></image>
								</label>
								<view class="mainImg">
									<image :src="imgUrl+item.mainimage" mode=""></image>
								</view>
								<view class="cartItemContent">
									<view class="content-title">
										{{item.title}}
									</view>
									<view class="content-attr">
										{{item.attr_0}},{{item.attr_1}}
									</view>
									<view class="content-price">
										<view class="price">¥ {{item.price}}</view>
										<view class="numOption">
											<view class="numBtn" @click="reduce(index)">-</view>
											<view class="numTxt"><input type="text" v-model="item.num"></view>
											<view class="numBtn" @click="add(index)">+</view>
										</view>
									</view>
								</view>
							</view>
						</uni-swipe-action-item>
					</uni-swipe-action>
					<!-- 类似于占位符底部结算拦用了固定定位防止数据被遮挡 -->
					<view style="height: var(--window-bottom);"></view>
					<!-- 底部结算拦开始 -->
					<view class="cartBottom">
						<label @click="allCheckChange">
							<image src="../../static/image/checkbox1.png" mode="" v-if="allCheck"></image>
							<image src="../../static/image/checkbox.png" mode="" v-else></image>
							<text>全选</text>
						</label>
						<view class="cartBottomRight">
							总价:<text class="money">¥</text><text class="allTotal">{{getAllCheck.price}}</text>
							<view class="payBtn" @click="cartBuy">
								去结算<text>(共{{getAllCheck.num}}件)</text>
							</view>
						</view>
					</view>
				</view>
			</view>
			<!-- 购物车列表结束 -->
		</view>
	</view>
</template>

<script>
	import uniSwipeAction from '../../componets/uni-swipe-action/uni-swipe-action.vue'
	import uniSwipeActionItem from '../../componets/uni-swipe-action-item/uni-swipe-action-item.vue'
	export default {
		components:{
			uniSwipeAction,
			uniSwipeActionItem
		},
		data(){
			return {
				options:[
				         {
				            text: '删除',
				            style: {
							 backgroundColor: '#dd524d',
				            }
				         }
						],
				cartList:[],//存放商品
				imgUrl:this.imgUrl,//统一图片格式
				isLogin:'',//是否登陆
				show:false//防止闪烁
			}
		},
		computed:{
			//全选事件
			allCheck(){
				var num=0
				for(var i=0;i<this.cartList.length;i++){
					if(this.cartList[i].flag==1){
						num++
					}
				}
				if(num==this.cartList.length){return true}
				else{return false}
			},
			//计算总价格和总数量
			getAllCheck(){
				var num = 0
				var price = 0
				for(var i=0;i<this.cartList.length;i++){
					if(this.cartList[i].flag==1){
						num+=parseInt(this.cartList[i].num)
						price+=parseFloat(parseFloat(this.cartList[i].price)*parseInt(this.cartList[i].num))
					}
				}
				return {"num":num,"price":price}
			}
		},
		// onUnload(){
		// 	console.log("onUnload")
		// },
		// beforeDestroy(){
		// 	console.log("beforeDestroy")
		// }
		onShow(){
			//获取购物车列表
			this.getData();
		},
		//用户离开购物车页面之后将用户的数据保存到数据库
		onHide(){
			console.log("onHide")
			//定义临时变量数组用于存储过滤后的数组并作为参数发请求
			var temp=[]
			for(var i=0;i<this.cartList.length;i++){
				temp.push({
					"num":this.cartList[i].num,//保存商品数量
					"attrid":this.cartList[i].attrid,//保存商品属性id
					"flag":this.cartList[i].flag,//保存商品标志位
				})
			}
			this.$request('member/savecart',{
				data:JSON.stringify(temp)
			}).then(res=>{
				console.log(res)
			})
		},
		methods:{
			//获取购物车列表函数
			getData(){
				this.$request('member/cartlist')
				.then(res=>{
					//未登陆
					console.log(res)
					if(res.tcode==0){
						this.isLogin = 0
					}else{
						this.cartList = res.data
						this.isLogin = 1
					}
					this.show = true
				})
			},
			//向右滑动删除商品函数
			delBtn(e,id,index){
				if(e.content.text=="删除"){
					uni.showModal({
					    title: '提示',
					    content: '是否要删除该商品',
					    success: res=>{
					        if (res.confirm) {//用户点击了确认
					           this.cartList.splice(index,1)
					           this.$request("member/delcart",{
					           	id:id
					           })
					           .then(res=>{
					           	uni.showToast({
					           		title:"删除成功",
									icon:"none"
					           	})
					           })
					        } else if (res.cancel) {//用户点击了取消
								console.log('用户点击取消');
					        }
					    }
					});
					return;
				}
			},
			//商品数量加减功能实现
			//1、减少
			reduce(index){
				if(this.cartList[index].num==1){return;}
				else{this.cartList[index].num--}
			},
			//2、增加
			add(index){
				if(parseInt(this.cartList[index].num)>=parseInt(this.cartList[index].stock)){return;}
				else{this.cartList[index].num++}
			},
			//复选框选中事件
			changeBox(index){
				this.cartList[index].flag=!this.cartList[index].flag
			},
			//全选按钮触发事件
			allCheckChange(){
				if(this.allCheck){
					for(var i=0;i<this.cartList.length;i++){
						this.cartList[i].flag=0;
					}
				}else{
					for(var i=0;i<this.cartList.length;i++){
						this.cartList[i].flag=1;
					}
				}
			},
			//结算按钮事件
			cartBuy(){
				var temp=[];
				var tempid=[]
				for(var i=0;i<this.cartList.length;i++){
					if(this.cartList[i].flag==1){
						temp.push({num:this.cartList[i].num,attrid:this.cartList[i].attrid})
						tempid.push(this.cartList[i].id)
					}
				}
				this.$request("/member/delcart",{id:tempid.toString()})
				.then(res=>{
					console.log(res)
				})
				uni.setStorageSync('ordershop',JSON.stringify(temp))
				this.$back('../order/order',1)
			}
		}
	}
</script>

<style>
	.cartEmpty {
		width: 296rpx;
		height: 296rpx;
		display: block;
		margin: 154rpx auto 0;
	}
	.cartEmptyTip {
		font-size: 28rpx;
		text-align: center;
		color: #999;
		line-height: 160rpx;
	}
	.cartLogin {
		width: 315rpx;
		height: 80rpx;
		color: #fff;
		background-color: #23baef;
		font-size: 30rpx;
		text-align: center;
		line-height: 80rpx;
		font-weight: 700rpx;
		margin: 0 auto;
	}
	.cartItem {
		display: flex;
		padding: 35rpx 20rpx 30rpx;
		border-top: 1rpx solid #E5E5E5;
	}
	.cartItem image {
		width: 200rpx;
		height: 200rpx;
	}
	.cartItem label {
		display: flex;
		align-items: center;
	}
	.cartItem label image {
		width: 33rpx;
		height: 33rpx;
	}
	.content-title {
		font-size: 28rpx;
		line-height: 40rpx;
		height: 80rpx;
		/* 控制显示行数 */
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp:2;//控制行数
		-webkit-box-orient:vertical;
		/* 控制显示行数 */
	}
	.content-attr{
		font-size: 24rpx;
		color: #999;
		line-height: 40rpx;
		margin-top: 10rpx;
	}
	.content-price {
		display: flex;
		height: 80rpx;
		align-items: center;
		font-size: 28rpx;
		justify-content: space-between;
		/* background-color:  #007AFF; */
		width: 470rpx;
	}
	.content-price  .price {
		color: red;
		font-weight: 700;
	}
	.numOption {
		display: flex;
		width: 154rpx;
		border: 1rpx solid #E5E5E5;
	}
	.numBtn {
		width: 44rpx;
		text-align: center;
		font-size: 28rpx;
	}
	.numTxt {
		flex: 1;
	}
	.numOption .numTxt input {
		width: 100%;
		border-left: 1rpx solid #E5E5E5;
		border-right: 1rpx solid #E5E5E5;
		font-size: 28rpx;
		text-align: center;
	}
	.cartBottom {
		position: fixed;
		background-color: #fff;
		bottom: var(--window-bottom);
		width: 100%;
		height: 106rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		font-size: 28rpx;
		border-top: 1rpx solid #E5E5E5;
	}
	.cartBottom label image {
		width: 30rpx;
		height: 30rpx;
		margin: 20rpx 20rpx 0 20rpx;
	}
	.cartBottomRight {
		display: flex;
		align-items: center;
		font-weight: 700;
	}
	.cartBottomRight .payBtn {
		width: 230rpx;
		height: 80rpx;
		text-align: center;
		line-height: 80rpx;
		background-color: #0BBBEF;
		color: #fff;
		margin: 0 20rpx;
		border-radius: 80rpx;
		font-weight: 700;
		font-size: 30rpx;
	}
	.cartBottomRight .payBtn text {
		font-size: 28rpx;
	}
	.allTotal {
		color: red;
		margin-left: 10rpx;
		font-size: 40rpx;
	}
	.money {
		color: red;
		font-weight: 700;
	}
</style>
