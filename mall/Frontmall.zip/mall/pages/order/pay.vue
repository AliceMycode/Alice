<template>
	<view class="pay">
		
		<!-- 支付信息开始 -->
		<view class="payOrder">
			<view class="payNumber">
				订单号：{{orderInfo.ordernum}}
			</view>
			<view class="payPrice">
				<text>¥</text>{{orderInfo.allprice}}
			</view>
			<view class="payTime">
				最迟支付时间: {{orderInfo.end_time}}
			</view>
		</view>
		<!-- 支付信息结束 -->
		
		
		<!-- 支付方式开始 -->
		<view class="payType">
			<view class="payTitle">请选择支付方式</view>
			<!-- 内部包裹多个radio需要在最外层包裹radio-group -->
			<radio-group @change="radioChange">
				<view class="payItem">
					<view class="wechaPayt">
						<i class="iconfont" style="color:#07d21c">&#xe63d;</i><text>微信支付</text>
					</view>
					<radio color="#00BFFF;" value="1"></radio>
				</view>
				<view class="payItem">
					<view class="AlPay">
						<i class="iconfont" style="color:#0f9ddf">&#xe647;</i><text>支付宝支付</text>
					</view>
					<radio  color="#00BFFF;" value="2" checked="true"></radio>
				</view>
			</radio-group>
			<!-- 内部包裹多个radio需要在最外层包裹radio-group -->
		</view>
		<!-- 支付方式结束 -->
		
		<!-- 支付按钮开始 -->
		<view class="payButton" @click="payStatus">确定支付</view>
		<!-- 支付按钮结束 -->
		
		
	</view>
</template>

<script>
	export default {
		data(){
			return{
				id:'',//订单id
				orderInfo:{},//存储订单数据
				type:2//支付类型，1表示微信支付，2表示支付宝支付
			}
		},
		onLoad(option){
			console.log(option)
			this.id = option.id;
			//获取订单id
			this.$request('member/payinfo',{
				id:option.id
			}).then(res=>{
				this.orderInfo = res.data
				//console.log(res)
			})
			//页面加载时获取提供服务商
			uni.getProvider({
			    service: 'payment',
			    success: function (res) {
			        console.log(res.provider)
			    }
			});
		},
		methods:{
			//支付函数
			async payment(payType){
				var orderInfo = await this.getOrderInfo(payType);
				uni.requestPayment({
				    provider: payType,
				    orderInfo: orderInfo.data, //微信、支付宝订单数据 【注意微信的订单信息，键值应该全部是小写，不能采用驼峰命名】
				    //支付成功
					success: (res)=>{
				       uni.redirectTo({
				       	url:'status?orderid='+this.id+'&status=1'
				       })
				    },
					//支付失败
				    fail: function (err) {
				       uni.redirectTo({
				       	url:'status?status=0'
				       })
				    }
				});
			},
			//单选框触发事件
			radioChange(e){
				this.type = e.target.value
			},
			payStatus(){
				//微信支付
				if(this.type==1){
					this.payment('wxpay')
				}
				//支付宝支付
				if(this.type==2){
					this.payment('alipay')
				}
			},
			//获取由提供服务商返回的支付订单信息
			getOrderInfo(type){
				return new Promise((resolve)=>{
					//未填写appid和通用链接使用标准基座编译用的是Dcloud公司的appid及对应的通用链接付款金额始终为一元
					uni.request({
						url:"https://demo.dcloud.net.cn/payment/?payid="+type+"&total=1",
						success(res){
							resolve(res)
					}
				  })
				  //未填写appid和通用链接使用标准基座编译用的是Dcloud公司的appid及对应的通用链接付款金额始终为一元
			   })
			}
			//使用自己账号发起支付需要改代码
			// this.$request('pay'+type,{orderid:this.id}).then(res=>{resolve(res)})
		}
	}
</script>

<style>
	.payType {
		width: 650rpx;
		margin: 58rpx auto 0;
	}
	.payType .payTitle {
		font-size: 28rpx;
		line-height: 55rpx;
	}
	.payItem {
		display: flex;
		justify-content: space-between;
		align-items: center;
		line-height: 76rpx;
	}
	.payItem i{
		font-size: 32rpx;
		margin-right: 20rpx;
	}
	.payItem radio {
		transform: scale(0.7);
	}
	.payButton {
		height: 80rpx;
		width: 624rpx;
		position: fixed;
		bottom: 120rpx;
		background-color: #00BFFF;
		color: #fff;
		font-weight: 700;
		text-align: center;
		line-height: 80rpx;
		border-radius: 80rpx;
		font-size: 30rpx;
		left: 50%;
		margin-left: -312rpx;
	}
	.payNumber{
		font-size: 24rpx;
		color: #999;
		text-align: center;
		padding-top: 54rpx;
	}
	.payPrice {
		font-size: 80rpx;
		font-weight: 700;
		display: flex;
		height: 120rpx;
		align-items: center;
		justify-content: center;
		
	}
	.payPrice text {
		font-size: 40rpx;
		margin-right: 10rpx;
	}
	.payTime {
		font-size: 24rpx;
		color: #999;
		text-align: center;
	}
</style>
