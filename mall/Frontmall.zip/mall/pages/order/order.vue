<template>
	<view v-if="show">
		<!-- 收货地址开始 -->
		<view class="address" v-if="addressFlag" @click="getAddressList">
			<view class="addressBox">
				<view class="addressIcon">
					<i class="iconfont">&#xe622;</i>
				</view>
				<view class="addressContent">
					<view class="addressUsername">
						收货人:&ensp;{{address.username}} &ensp;&ensp;{{address.telphone}}
					</view>
					<view class="addressInfo">
						{{address.city}}{{address.address}}
					</view>
				</view>
				<view class="addressMore">
					<i class="iconfont">&#xe60b;</i>
				</view>
			</view>
			<!-- 底部边框线样式 -->
			<view class="addressLine"></view>
		</view>
		<!-- 收货地址结束 -->
		
		<!-- 没有添加收货地址时显示 -->
		<view @click="addAddress" class="addressEmpty" v-else>
			+ 暂无收货地址,请添加
		</view>
		<!-- 没有添加收货地址时显示 -->
		
	
		<!-- 商品列表开始 -->
		<view class="shopList">
			<view class="shopItem" v-for="(item,index) in shop" :key="index">
				<view class="shopItemLeft">
					<image :src="imgUrl+item.mainimage" mode=""></image>
				</view>
				<view class="shopItemRight">
					<view class="shopTitle">
						{{item.title}}
					</view>
					<view class="shopAttr">
						{{item.attr_0}},{{item.attr_1}}
					</view>
					<view class="shopPrice">
						<text>¥ {{item.price}}</text><text class="num">x{{item.num}}</text>
					</view>
				</view>
			</view>
		</view>
		<!-- 商品列表结束 -->
	
		<!-- 付款信息开始 -->
		<view class="orderBox">
			<view class="orderItem">
				<view class="orderItemTitle">应付金额</view>
				<view class="orderItemPrice">¥ {{total.price}}</view>
			</view>
			<view class="orderItem">
				<view class="orderItemTitle">配送方式</view>
				<view class="orderItemPrice">
					<picker @change="logistic" :value="index" :range="array" range-key="name">
					     <view class="uni-input">{{array[index].name}}</view>
					  </picker>
					  <i class="iconfont">&#xe60b;</i>
				</view>
			</view>
			<view class="orderMessage">
				<input type="text" value="" placeholder="请留言"/>
			</view>
			<view class="orderItem">
				<view class="orderItemTitle">总价</view>
				<view class="orderItemPrice">合计{{total.num}}件商品，总共¥ {{endPrice}}</view>
			</view>
		</view>
		<!-- 付款信息结束 -->

		<!-- 占位符使整个页面撑开防止被遮挡 -->
		<view class="empty" style="height: 80rpx;"></view>
		<!-- 占位符使整个页面撑开防止被遮挡 -->
		
		
		<!-- 底部结算拦开始 -->
		<view class="orderBottom">
			<view class="">
				<i>总计:</i><text class="totalPrice">¥ {{endPrice}}</text>
			</view>
			<view class="orderBottomBtn" @click="payBtn">立即购买</view>
		</view>
		<!-- 底部结算拦结束 -->	

	</view>
</template>

<script>
	export default {
		data() {
			return {
				//array:['请选择配送方式','申通快递','圆通快递','顺丰速运','韵达快递'],
				array:[{"name":"请选择配送方式"}],
				index:0,//当前物流索引
				shop:[],//存储商品信息
				total:[],//存储总价以及总数量
				address:[],//存放地址
				addressFlag:'',//控制地址拦的显示隐藏
				endPrice:'',//选完物流之后的最终价格
				show:false,
				message:''
			}
		},
		onShow(){
			this.getData();
			this.getAddressInfo();
		},
		//四舍五入保留两位小数
		filters:{
			toFixed(num=2){
				return parseFloat(this.total.price).toFixed(num)
			}
		},
		methods: {
			//从已有的地址里选收货地址
			getAddressList(){
				this.$href('../address/list?backurl=1',1)
			},
			//添加地址
			addAddress(){
				this.$href('../address/add?backurl=1',1)
			},
			//获取地址信息
			getAddressInfo(){
				this.$request('member/getOrderAddress',{
					"id":uni.getStorageSync('addressId')//为空时返回默认地址
				}).then(res=>{
					console.log(res)
					uni.setStorageSync('addressId',res.data.id)//注意有这条代码和没有这条代码的效果
					this.address = res.data//保存地址信息
					this.addressFlag = res.code//控制地址信息拦的切换
				})
			},
			//获取商品信息
			getData(){
				this.$request('member/getBuyShopInfo',{
					"data":uni.getStorageSync('ordershop')
				}).then(res=>{
					console.log(res)
					this.shop = res.data.shop
					this.total = res.data.all
					this.array = this.array.concat(res.data.logistics)//数组拼接
					this.endPrice = res.data.all.price//刚进来没选物流方式时显示应付金额
					this.show=true
				})
				
			},
			// 备注一下
			//顺丰:福建省内件一般一公斤之内20元左右，每超出一公斤另加2-5元，省外件一般起步价（一公斤以内）12-15元，每超出1公斤加5-8元
			//圆通快递：福建省内件一般一公斤之内10元左右，每超出一公斤另加2-5元，省外件一般起步价（一公斤以内）12-15元，每超出1公斤加5-8元。
			//EMS：福建省内件一般一公斤之内20元左右，每超出一公斤另加2-5元，省外件一般起步价（一公斤以内）12-15元，每超出1公斤加5-8元。
			//申通快递：福建省内件一般一公斤之内10元左右，每超出一公斤另加2-5元，省外件一般起步价（一公斤以内）12-15元，每超出1公斤加5-8元。
			//中通快递：福建省内件一般一公斤之内10元左右，每超出一公斤另加2-5元，省外件一般起步价（一公斤以内）12-15元，每超出1公斤加5-8元。
			//选择物流事件
			logistic(e){
				this.index = e.target.value
				console.log(e)
				if(this.index!=0){
					this.endPrice = parseFloat(this.total.price)+parseFloat(this.array[this.index].price)//转化为小数
				}else{
					this.endPrice = this.total.price
				}
			},
			//点击立即支付跳转导支付页面
			payBtn(){
				//没有选择配送方式先选择配送方式
				if(this.index==0){
					uni.showToast({
						title:"请选择配送方式",
						icon:"none"
					})
					return;
				}
				//没有选择收货地址先选择收货地址
				if(uni.getStorageSync('addressId')==''){
					uni.showToast({
						title:"请选择收货地址",
						icon:"none"
					})
					return;
				}
				//用户选完配送方式和收货地址后才发请求
				this.$request("member/order",{
					orderShop:uni.getStorageSync('ordershop'),
					addressid:uni.getStorageSync('addressId'),
					price:this.endPrice,
					logistics:this.array[this.index].id,
					message:this.message
					}).then(res=>{
					console.log(res)
					if(res.code==1){
						this.$href('pay?id='+res.data.id,1)
					}
				})
			}
		}
	}
</script>

<style>
	page{
		background-color: #F4F4F4;
	}
	.addressBox {
		width: 695rpx;
		height: 200rpx;
		background-color: #fff;
		margin: 20rpx auto;
		display: flex;
		border-radius: 10rpx;
	}
	.addressEmpty {
		width: 695rpx;
		height: 90rpx;
		background-color: #fff;
		text-align: center;
		line-height: 90rpx;
		color: #00BFFF;
		border-radius: 10rpx;
		margin: 20rpx auto 0;
	}
	.addressIcon {
		width: 50rpx;
		display: flex;
		justify-content: center;
		line-height: 50rpx;
		font-weight: 700;
	}
	.addressContent {
		flex: 1;
	}
	.addressContent .addressUsername {
		font-size: 30rpx;
		color: #000;
		line-height: 50rpx;
		font-weight: 700;
	}
	.addressContent .addressInfo {
		font-size: 24rpx;
		color: #999;
		/* 控制显示行数 */
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp:3;//控制行数
		-webkit-box-orient:vertical;
		/* 控制显示行数 */
	}
	.addressMore {
		width: 50rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.address {
		position: relative;
		width: 695rpx;
		height: 200rpx;
		margin: 0 auto;
		overflow: hidden;
		border-radius: 10rpx;
	}
	.addressLine{
		    height: 8rpx;
		    background-image: -webkit-linear-gradient(315deg,#82c9ff 8px,transparent 0,transparent 16px,#ff8282 0,#ff8282 32px,transparent 0,transparent 0,transparent 40px,#82c9ff 0,#82c9ff);
		    background-image: linear-gradient(135deg,#82c9ff 8px,transparent 0,transparent 16px,#ff8282 0,#ff8282 32px,transparent 0,transparent 0,transparent 40px,#82c9ff 0,#82c9ff);
		    background-color: #fff;
		    background-size: 136rpx 8rpx;
			position: absolute;
			bottom: 0;
			width: 100%;
	}
	.shopList {
		width: 695rpx;
		background-color: #fff;
		margin: 20rpx auto 0;
	}
	.shopList .shopItem {
		display: flex;
		padding: 10rpx 0rpx;
		border-top: 2rpx solid #E5E5E5;
		margin: 0 20rpx;
	}
	.shopList .shopItem:nth-of-type(1){
		border: none;
	}
	.shopItemLeft image {
		width: 200rpx;
		height: 200rpx;
	}
	.shopItemRight .shopTitle {
		font-size: 28rpx;
		/* 控制显示行数 */
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp:2;//控制行数
		-webkit-box-orient:vertical;
		/* 控制显示行数 */
	}
	.shopItemRight .shopAttr {
		font-size: 24rpx;
		color: #999;
		line-height: 40rpx;
	}
	.shopItemRight .shopPrice {
		line-height: 80rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		color: red;
		font-weight: 700;
	}
	.shopItemRight .shopPrice .num {
		color: #999;
	}
	.orderBox {
		margin: 20rpx auto;
		width: 695rpx;
		border-radius: 10rpx;
		overflow: hidden;
		background-color: #fff;
		padding: 25rpx 0;
	}
	.orderItem {
		height: 80rpx;
		display: flex;
		justify-content: space-between;
		padding: 0 20rpx;
		align-items: center;
		font-size: 28rpx;
	}
	.orderMessage {
		margin: 0 20rpx;
		background-color: #F4F4F4;
		height: 70rpx;
		border-radius: 70rpx;
		display: flex;
		align-items: center;
	}
	.orderMessage input {
		margin-left: 20rpx;
		font-size: 24rpx;
	}
	.orderItemPrice {
		color: #999;
		display: flex;
		align-items: center;
		line-height: 80rpx;
	}
	.orderBottom {
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 100%;
		height: 80rpx;
		background-color: #fff;
		position: fixed;
		bottom: 0;
		z-index: 10;
		height: 100rpx;
	}
	.orderBottom i {
		padding-left: 30rpx;
		font-size: 30rpx;
		margin-right: 10rpx;
		font-weight: 700;
	}
	.totalPrice {
		font-weight: 700;
		color: red;
		font-size: 40rpx;
	}
	.orderBottomBtn {
		width: 300rpx;
		height: 100rpx;
		background-color: #00BFFF;
		text-align: center;
		line-height: 100rpx;
		font-size: 40rpx;
		color: #fff;
		font-weight: 700;
	}
</style>
