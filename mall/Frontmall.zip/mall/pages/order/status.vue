<template>
	<view class="status">
		<view v-if="status==1">
			<image src="../../static/image/success.png" mode="" class="statusImg"></image>
			<view class="payStatus">支付成功</view>
			<view class="payTips">支付成功后商家会尽快发货</view>
			<view class="payTips">请小主人耐心等待哟~</view>
			<view class="statusBtn">
				<view class="statusOrder" @click="gotoOrder">
					查看订单
				</view>
				<view class="statusIndex" @click="gotoHome">
					回到首页
				</view>
			</view>
		</view>
		<view v-else>
			<image src="../../static/image/error.png" mode="" class="statusImg"></image>
			<view class="payStatus">支付失败</view>
			<view class="payTips">支付失败请返回订单页面重新下单</view>
			<view class="statusBtn">
				<view class="statusIndex" @click="gotoHome">
					回到首页
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		data(){
			return {
				status:'',//0表示支付失败1支付成功
				orderid:''
			}
		},
		onLoad(Option){
			this.status = Option.status
			this.orderid = Option.orderid
			console.log(Option)
		},
		methods:{
			//回到订单
			gotoOrder(){
				this.$href('../member/orderdetail?orderid='+this.orderid)
			},
			//回到首页
			gotoHome(){
				uni.switchTab({
					url:'../index/index'
				})
			}
		}
	}
</script>

<style>
	.statusImg {
		width: 160rpx;
		height: 160rpx;
		display: block;
		margin: 120rpx auto 16rpx;
	}
	.payStatus {
		font-size: 32rpx;
		line-height: 90rpx;
		text-align: center;
	}
	.payTips {
		font-szie:128rpx;
		color: #999;
		line-height: 50rpx;
		text-align: center;
	}
	.statusBtn {
		display: flex;
		margin-top: 80rpx;
		justify-content: center;
	}
	.statusIndex {
		width: 200rpx;
		height: 50rpx;
		color: #fff;
		font-size: 28rpx;
		background-color: #00BFFF;
		line-height: 50rpx;
		text-align: center;
		font-weight: 700;
		margin-left: 38rpx;
	}
	.statusOrder {
		width: 200rpx;
		height: 49rpx;
		font-size: 28rpx;
		line-height: 50rpx;
		text-align: center;
		font-weight: 700;
		color: #999;
		border: 1rpx solid #E5E5E5;
		margin-right: 38rpx;
	}
</style>
