<template>
	<view>
		<view class="search">
			<view class="searchBox">
				<navigator url="#">
					<image src="../../static/image/search2.png" mode=""></image>
					<text>搜索全部</text>
				</navigator>
			</view>
		</view>
		<view class="cate">
			<view class="cateLeft">
				<scroll-view class="cateLeftList" scroll-y="true" :scroll-top="scrollTop">
					<view class="cateLeftItem" 
					:class="{cateActive:index==current}"
					v-for="(item,index) in cates" 
					:key="index"
					@click="leftMenuClick(index)"
					>
						{{item.catename}}
						<view class="cateLine"></view>
					</view>
				</scroll-view>
			</view>
			<view class="cateRight">
					<scroll-view class="cateRightScroll" 
					scroll-y="true" 
					:scroll-into-view="'cates'+mainCurrent"
					scroll-with-animation
					@scroll="rightScroll"
					>
						<view class="cateItem"
						v-for="(item,index) in cates"
						:key="index"
						:id="'cates'+index"		
						>
						<!-- 给每个item绑定一个id进行左右联动 -->
							<view class="cateRightTitle">
								————<text>{{item.catename}}</text>————
							</view>
							<view class="cateRightList">
								<view class="cateRightItem"
								v-for="(item1,index1) in item.product"
								:key="index1"
								>
									<navigator hover-class="none" :url="'../detail/detail?id='+item1.id">
										<image :src="imgUrl+item1.mainimage" mode=""></image>
										<text>{{item1.smalltitle}}1</text>
									</navigator>
								</view>
							</view>
						</view>
					</scroll-view>
			</view>
		</view>
	
	</view>
</template>

<script>
	/*
	分类页面有三个bug
	1、current的值会随页面的滚动而改变而实际上只有我们想要的效果是只有我们点击左侧菜单栏的选项卡时current的值才会改变
		解决方案：
		重新定义一个变量mainCurrent，让他只有点击侧菜单栏的选项卡时current的值才会改变；
	2、最后一个item的top和bottom的值远远大于滚动条到达底部时的值，导致i的值不会变也就是current的值不会变
		解决方案：
		let view = uni.createSelectorQuery().in(this).select("#cates"+i);第一个匹配选择器selector的节点要动态变化
	3、右侧页面滚动时，左侧菜单栏选项卡到达可视页面底部时，如果在滚动滚动体选项卡看不见
		解决方案：
		给左侧选项卡父级元素绑定:scroll-top属性
	*/ 
	export default {
		data() {
			return {
				cates:[],//存放分类数据
				current:0,//分类页面左侧导航栏激活索引号
				rectInfo:[],//存放节点的top和bottom值
				mainCurrent:0,//防止curretn每次滚动页面时都重新赋值,导致:scroll-into-view="'cates'+current"中都current重新赋值
				scrollTop:0
			}
		},
		onLoad(){
			this.getData();
		},
		mounted(){
			setTimeout(()=>{
				this.getRectInfo();
			},200)
		},
		methods: {
			getData(){
				uni.request({
					url:this.apiUrl+'index/cate',
					data:{},
					success: (res) => {
						var data = res.data.data;
						this.cates = data;
					}
				})
			},
			//左侧菜单栏切换
			leftMenuClick(index){
				this.current= index;
				this.mainCurrent = index;
				this.scrollTop = index*50;
				//this.scrollTop = i*uni-upx2pex(100);
			},
			//获取节点信息
			getRectInfo(){
				var top = 0;
				var bottom = 0;
				var temp = 0;//临时变量存放上一个节点的高度
				//循环输出cates0/1/2/3....的top和bottom值
				for(var i = 0;i < this.cates.length;i++){
					let view = uni.createSelectorQuery().in(this).select("#cates"+i);
					view.fields({
					  size: true,
					  rect:true
					}, data => {
					  top = temp;
					  //以一下两条代码不能调换
					  bottom = temp + data.height;
					  temp += data.height;
					  this.rectInfo[i] = {'top':top,'bottom':bottom};
					}).exec();
				}
			},
			//监听右侧滚动条事件
			rightScroll(e){
				var scrollTop = e.detail.scrollTop;
				for(var i = 0;i < this.rectInfo.length;i++){
					if(scrollTop > this.rectInfo[i].top && scrollTop < this.rectInfo[i].bottom){
						this.current=i;
						this.scrollTop = i*50;
						//this.scrollTop = i*uni-upx2pex(100);
					}
				}
			},
		}
	}
</script>

<style>
	page {
		 background-color: #f7f7f7;
	}
	.search {
		height: 110rpx;
		width: 100%;
		background-color: #FFFFFF;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.searchBox {
		width: 690rpx;
		height: 70rpx;
		border-radius: 10rpx;
		font-size: 28rpx;
		color: #999;
		background-color: #f7f7f7;
	}
	.searchBox image {
		width: 38rpx;
		height: 38rpx;
		margin-right: 10rpx;
	}
	.searchBox navigator {
		display: flex;
		justify-content: center;
		align-items: center;
		height:70rpx
	}
	.cate {
		position: absolute;
		top: 120rpx;
		bottom: 0;
		width: 100%;
		display: flex;
	}
	.cateLeft {
		width: 200rpx;
		height: 100%;
		background-color: #f7f7f7;
	}
	.cateLeftList,.cateRightScroll{
		height: 100%;
		overflow: auto;
	}
	.cateLeftList .cateLeftItem {
		font-size: 28rpx;
		color: #000;
		line-height: 100rpx;
		text-align: center;
		position: relative;
	}
	.cateActive {
		background-color: #FFFFFF;
	}
	.cateLine {
		width: 8rpx;
		height: 40rpx;
		background-color: #f7f7f7;
		position: absolute;
		top: 30rpx;
	}
	.cateActive .cateLine {
		background-color: #15B8f9;
	}
	.cateRight {
		width: 550rpx;
		height: 100%;
		background-color: #FFFFFF;
	}
	.cateRightTitle {
		line-height: 86rpx;
		padding-top: 16rpx;
		color: #999;
		font-size: 28rpx;
		text-align: center;
	}
	.cateRightTitle text {
		padding: 0 30rpx;
	}
	.cateRightItem {
		width: 33.33%;
		float: left;
		margin-top: 20rpx;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}
	.cateRightItem image {
		width: 160rpx;
		height: 160rpx;
		display: block;
		margin: 0 auto;
	}
	.cateRightItem text {
		display: block;
		width: 100%;
		line-height: 36rpx;
		font-size: 24rpx;
		text-align: center;
	}
	.cateRightList {
		/* 可有可无 */
		overflow: hidden;
		height: 100%;
	}
</style>
