<template>
	<view>
		<view class="search">
			<view class="searchBox">
				<navigator url="#">
					<image src="../../static/image/search2.png" mode=""></image>
					<text>搜索全部</text>
				</navigator>
			</view>
		</view>
		<view class="cate">
			<view class="cateLeft">
				<view class="cateLeftList">
					<view class="cateLeftItem cateActive">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
					<view class="cateLeftItem">
						精品推荐1
						<view class="cateLine"></view>
					</view>
				</view>
			</view>
			<view class="cateRight">
					<view class="cateRightScroll">
						<view class="cateItem">
							<view class="cateRightTitle">
								————<text>精品推荐</text>————
							</view>
							<view class="cateRightList">
								<view class="cateRightItem">
									<image src="../../static/image/p1.png" mode=""></image>
									<text>手机1</text>
								</view>
								<view class="cateRightItem">
									<image src="../../static/image/p1.png" mode=""></image>
									<text>手机2</text>
								</view>
								<view class="cateRightItem">
									<image src="../../static/image/p1.png" mode=""></image>
									<text>手机3</text>
								</view>
								<view class="cateRightItem">
									<image src="../../static/image/p1.png" mode=""></image>
									<text>手机4</text>
								</view>
							</view>
						</view>
						<view class="cateItem">
							<view class="cateRightTitle">
								————<text>精品推荐</text>————
							</view>
							<view class="cateRightList">
								<view class="cateRightItem">
									<image src="../../static/image/p1.png" mode=""></image>
									<text>手机1</text>
								</view>
								<view class="cateRightItem">
									<image src="../../static/image/p1.png" mode=""></image>
									<text>手机2</text>
								</view>
								<view class="cateRightItem">
									<image src="../../static/image/p1.png" mode=""></image>
									<text>手机3</text>
								</view>
								<view class="cateRightItem">
									<image src="../../static/image/p1.png" mode=""></image>
									<text>手机4</text>
								</view>
							</view>
							<view class="empty" style="height: 20rpx; width: 100%;"></view>
						</view>
					</view>
			</view>
		</view>
	
	
	
	
	
	
	
	
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	page {
		 background-color: #f7f7f7;
	}
	.search {
		height: 110rpx;
		width: 100%;
		background-color: #FFFFFF;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.searchBox {
		width: 690rpx;
		height: 70rpx;
		border-radius: 10rpx;
		font-size: 28rpx;
		color: #999;
		background-color: #f7f7f7;
	}
	.searchBox image {
		width: 38rpx;
		height: 38rpx;
		margin-right: 10rpx;
	}
	.searchBox navigator {
		display: flex;
		justify-content: center;
		align-items: center;
		height:70rpx
	}
	.cate {
		position: absolute;
		top: 120rpx;
		bottom: 0;
		width: 100%;
		display: flex;
	}
	.cateLeft {
		width: 200rpx;
		height: 100%;
		background-color: #f7f7f7;
	}
	.cateLeftList,.cateRightScroll{
		height: 100%;
		overflow: auto;
	}
	.cateLeftList .cateLeftItem {
		font-size: 28rpx;
		color: #000;
		line-height: 100rpx;
		text-align: center;
		position: relative;
	}
	.cateActive {
		background-color: #FFFFFF;
	}
	.cateLine {
		width: 8rpx;
		height: 40rpx;
		background-color: #f7f7f7;
		position: absolute;
		top: 30rpx;
	}
	.cateActive .cateLine {
		background-color: #15B8f9;
	}
	.cateRight {
		width: 550rpx;
		height: 100%;
		background-color: #FFFFFF;
	}
	.cateRightTitle {
		line-height: 86rpx;
		padding-top: 16rpx;
		color: #999;
		font-size: 28rpx;
		text-align: center;
	}
	.cateRightTitle text {
		padding: 0 30rpx;
	}
	.cateRightItem {
		width: 33.33%;
		float: left;
		margin-top: 20rpx;
	}
	.cateRightItem image {
		width: 160rpx;
		height: 160rpx;
		display: block;
		margin: 0 auto;
	}
	.cateRightItem text {
		display: block;
		width: 100%;
		line-height: 36rpx;
		font-size: 24rpx;
		text-align: center;
	}
	.cateRightList {
		overflow: hidden;
		height: 100%;
	}
</style>
