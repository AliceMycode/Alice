<template>
	<view>
		<view class="logo">
			<image src="../../static/OIP.jpeg" mode=""></image>
		</view>
		<view class="formList">
			<view class="formItem">
				<input  v-model="telphone" placeholder="请输入手机号"/>
			</view>
			<view class="formItem">
				<input type="text" v-model="code" placeholder="请输入验证码"/>
				<!-- <button type="default" class="getCode">获取验证码</button> -->
				<view class="getCode"
				:class="{ActiveSelect:codeFlag}"
				@click="getCode"
				>{{codeTxt}}</view> 
			</view>
			<view class="formItem">
				<input type="text" v-model="password" placeholder="请输入密码"/>
			</view>
		</view>
		<view class="registerBtn" @click="register">
			注册
		</view>
		<view class="loginTxt">
			已有账号?<navigator url="../login/login">点击登录</navigator>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				codeTxt:'获取验证码',
				codeFlag:true,//true表示可以点击false表示不可以点击
				telphone:'',//获取输入框手机号默认为空
				code:'',//用于接收验证码
				password:''//用于存放密码
				
			}
		},
		methods: {
			//获取验证码
			getCode(){
				//点击获取验证码时首先验证手机号格式是否正确：包括是否为空、长度是否正确
				if(!this.check.telphone(this.telphone)){
					return;
				}
				
				if(this.codeFlag==false){
					return;
				}
				this.sendMessage()
				// this.codeFlag = false;
				// var time = 10
				// this.codeTxt = '重新获取('+time+')'
				// var timer = setInterval(()=>{
				// 	if(time==1){
				// 		clearInterval(timer);
				// 		this.codeTxt = '获取验证码'
				// 		this.codeFlag = true;
				// 	}else{
				// 		time--;
				// 		this.codeTxt = '重新获取('+time+')'
				// 	}
					
				// },1000)
			},
			sendMessage(){
				uni.request({
					url:this.apiUrl+'index/getSmsCode',
					method:"POST",
					data:{telphone:this.telphone},
						success:(res) => {
							if(res.data.result!=0){
								uni.showToast({
									title:res.data.errmsg,
									icon:'none'
								})
							}
							else
								{
									//result!=0时才开始倒计时
									this.codeFlag = false;
									var time = 10
									this.codeTxt = '重新获取('+time+')'
									var timer = setInterval(()=>{
									if(time==1){
										clearInterval(timer);
										this.codeTxt = '获取验证码'
										this.codeFlag = true;
									}else{
										time--;
										this.codeTxt = '重新获取('+time+')'
									}
									
								},1000)
							}
						}
				})
			},
			register(){
				//验证手机格式是否正确
				if(!this.check.telphone(this.telphone)){
					return;
				}
				//验证密码格式是否正确
				if(!this.check.password(this.password)){
					return;
				}
				//验证验证码石是否正确
				if(!this.check.code(this.code)){
					return;
				}
				//都正确之后才发请求
				uni.request({
					url:this.apiUrl+'index/register',
					method:"POST",
					data:{
						telphone:this.telphone,
						password:this.password,
						code:this.code
					},
					success:(res) => {
						console.log(res);
					}
				})
			}
		},
	}
</script>

<style>
	.logo {
		width: 250rpx;
		height: 250rpx;
		margin: 150rpx auto 15rpx;
		
	}
	.logo image {
		width: 100%;
		height: 100%;
	}
	.formItem {
		height: 74rpx;
		padding-top: 36rpx;
		border-bottom: 1rpx solid #E5E5E5;
		margin: 0 100rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.formItem input {
		font-size: 28rpx;
	}
	.getCode {
		width: 180rpx;
		height: 60rpx;
		color: #666;
		background-color: #F7F7F7;
		line-height: 60rpx;
		font-size: 24rpx;
		border: none;
		text-align: center;
	}
	.getCode.ActiveSelect {
			background-color: #00BFFF;
			color: #fff;
	}
	.registerBtn {
		margin: 60rpx 100rpx 0;
		height: 90rpx;
		background-color: #00BFFF;
		color: #fff;
		line-height: 90rpx;
		font-size: 30rpx;
		font-weight: 700;
		text-align: center;
		border-radius: 5rpx;
	}
	.loginTxt {
		display: flex;
		justify-content: center;
		align-items: center;
		height: 120rpx;
		font-size: 24rpx;
	}
	.loginTxt navigator {
		color: #00BFFF;
		margin-left: 20rpx;
	}
</style>
