<template>
	<view class="content">
		<!-- 顶部导航栏 -->
		<MyHeader :recommend="recommend_cate"></MyHeader>
		<!-- 首页轮播图 -->
		<MyIndexSwiper :swiper="banner" swiperHeight="390rpx" swiperActive="#fff" width="100%" height="390rpx"></MyIndexSwiper>
		<!-- 商品服务栏 -->
		<IndexShopNav :actives="active" :icons="icon"></IndexShopNav>
		<!-- 商品广告栏 -->
		<IndexAd :ads="ad"></IndexAd>
		<!-- 楼层1-->
		<view class="floor" v-for="(item,index) in cates" :key="index">
			<!-- <>{{}}</>尖括号之间才用花括号绑定数据，尖括号里面用v-bind绑定数据即用：-->
			<Title :name="item.content[0].title"></Title>
			<!-- 如果item.content.length==1显示 -->
			<template v-if="item.content.length==1">
				<view class="adImg">
						<image class="adImg" :src="imgUrl+item.content[0].img" mode=""></image>
				</view>
			</template>
			<!-- 如果item.content.length==2显示 --> 
			<template v-else>
				<IndexTable :tables="item.content"></IndexTable>
			</template>
				<shopList :catess="item.product"></shopList>
		</view>
		
		
		<!-- 楼层2 -->
		<!-- <view class="floor">
			<Title name="魅族声乐"></Title>
			<IndexTable></IndexTable>
			<view class="shopList">
				<shopItem></shopItem>
			</view>
		</view> -->
		<!-- 楼层3 -->
		<!-- <view class="floor">
			<Title name="魅族声乐"></Title>
			<IndexTable></IndexTable>
			<view class="shopList">
				<shopItem></shopItem>
			</view>
		</view> -->
		
		
		
		
		
		
		
		
	</view>
</template>
<!-- https://www.showdoc.com.cn/665799556451097/3868147264181727 -->
<script>
	import MyHeader from '../../componets/MyHeader.vue'
	import MyIndexSwiper from '../../componets/MyIndexSwiper.vue'
	import IndexShopNav from '../../componets/IndexShopNav.vue'
	import IndexAd from '../../componets/IndexAd.vue'
	import Title from '../../componets/title.vue'
	import shopList from '../../componets/shopList.vue'
	import IndexTable from '../../componets/Indextable.vue'
	export default {
		data() {
			return {
				title: 'Hello',
				banner:[],//轮播图
				recommend_cate:[],//顶部推荐分类
				active:[],
				icon:[],
				ad:[],
				cates:[]
			}
		},
		components: {
			MyHeader,
			MyIndexSwiper,
			IndexShopNav,
			IndexAd,
			Title,
			shopList,
			IndexTable
		},
		onLoad() {
			this.getData();
		},
		methods: {
			getData(){
				uni.request({
					url: this.apiUrl+'index', 
					success: (res) => {
						var data = res.data.data;
						this.recommend_cate = data.recommend_cate;
						this.banner =data.banner;
						this.active = data.active;
						this.icon = data.icon;
						this.ad = data.floor;
						this.cates = data.cate
						console.log(data)
					}
				});
			}
		}
	}
</script>

<style>
	page {
		background: #f4f4f4;
	}

	.adImg {
		width: 100%;
		height: 345rpx;
	}
</style>
