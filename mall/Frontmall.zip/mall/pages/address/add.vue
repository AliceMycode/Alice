<template>
	<view>
		<!-- 添加地址开始 -->
		<view class="username">
			<view class="itemTitle">
				收货人:
			</view>
			<input type="text" v-model="username" placeholder="收货人姓名">
		</view>
		<view class="addressItem">
			<view class="itemTitle">
			
			</view>
			<text :class="{sexActive:sex==1}" @click="sexChange(1)">先生</text>
			<text :class="{sexActive:sex==0}" @click="sexChange(0)">女士</text>
		</view>
		<view class="addressItem">
			<view class="itemTitle">
				电话号码:
			</view>
			<input type="text" v-model="telphone" placeholder="收货人电话号码">
		</view>
		<view class="addressItem">
			<view class="itemTitle">
			收货地址:
			</view>
			 <pickerAddress class="city" @change="change">{{city}}</pickerAddress>
		</view>
		<view class="addressBox">
			<view class="itemTitle">
				详细地址:
			</view>
			<textarea v-model="address" placeholder="请输入详细收货地址" />
		</view>
		<!-- 添加地址结束 -->
		
		<!-- 默认地址拦开始 -->
		<view class="defaults">
			<view class="itemTitle">默认地址:</view>
			<switch checked="true" @change="defaultChange" style="transform: scale(0.7);"></switch>
		</view>
		<!-- 默认地址拦结束 -->
		
		<!-- 按钮开始 -->
		<view class="saeAddress" @click="addAddress">保存收货地址</view>
		<!-- 按钮结束 -->
	</view>
</template>

<script>
	//导入插件
	 import pickerAddress from '../../componets/pickerAddress/pickerAddress.vue'
	export default {
		components:{
			pickerAddress
		},
		data() {
			return {
				 city: '请选择收货地址',
				 username:'',
				 telphone:'',
				 address:'',
				 default:1,//0表示设置为默认地址1表示不设置为默认地址
				 sex:1,//0表示女士1表示男生
				 backurl:''//用于在地址页面添加完地址后跳转到订单页面
			}
		},
		onLoad(Option){
			if(Option.backurl==1){
				this.backurl = 1
			}else{
				this.backurl = 0
			}
		},
		methods: {
			//性别切换
			sexChange(index){
				this.sex  = index
			},
			//监听默认按钮
			defaultChange(e){
				if(e.target.value){
					this.default = 1
				}else{
					this.default = 0
				}
			},
			//左右滑动事件监听
			change(data) {
			        this.city = data.data.join('')
			        console.log(data.data.join(''))
			    },
			//添加地址
			addAddress(){
				//前端格式验证
				//1、验证用户名
				if(!this.check.username(this.username)){return;}
				//2、验证电话号码
				if(!this.check.telphone(this.telphone)){return;}
				//3、验证收货地址
				if(!this.check.city(this.city)){return;}
				//4、验证收货地址
				if(!this.check.address(this.address)){return;}
				//地址信息格式都正确才发请求
				this.$request('member/addressAdd',{
					username:this.username,
					telphone:this.telphone,
					city:this.city,
					address:this.address,
					default:this.default,
					sex:this.sex
				})
				.then(res=>{
					console.log(res)
					uni.showToast({
						title:"添加地址成功",
						icon:"none"
					})
					this.username = '',
					this.city = '请选择收货地址',
					this.telphone = '',
					this.address = ''
					this.$href('list?backurl='+this.backurl,1)
				})
			}
		}
	}
</script>

<style>
	.username {
		padding: 0 30rpx;
		line-height: 90rpx;
		display: flex;
		align-items: center;
	}
	.itemTitle {
		width: 140rpx;
		font-size: 28rpx;
	}
	.username input {
		border-bottom: 1rpx solid #E5E5E5;
		flex: 1;
		height: 90rpx;
	}
	.addressItem {
		padding: 0 30rpx;
		display: flex;
		height: 90rpx;
		align-items: center;
		border-bottom: 1rpx solid #E5E5E5;
	}
	.addressItem text {
		display: block;
		width: 80rpx;
		height: 45rpx;
		border: 1rpx solid #EEEEEE;
		margin-right: 10rpx;
		font-size: 24rpx;
		text-align: center;
		line-height: 45rpx;
		color: #999;
	}
	.addressBox {
		display: flex;
		border-bottom: 1rpx solid #E5E5E5;
		height: 180rpx;
		padding: 0 0 0rpx 30rpx;
		line-height: 180rpx;
	}
	textarea {
		/* border: 1rpx solid red; */
		padding-left: 20rpx;
		height: 100%;
	}
	.addressBox .itemTitle {
		border-right: 1rpx solid #E5E5E5;
	}
	.saeAddress {
		width: 600rpx;
		height: 80rpx;
		background-color: #0BBBEF;
		color: #fff;
		font-size: 30rpx;
		font-weight: 700;
		margin: 80rpx auto;
		text-align: center;
		line-height: 80rpx;
		border-radius: 80rpx;
	}
	.city {
		font-size: 28rpx;
		color: #000;
	}
	.defaults {
		display: flex;
		justify-content: space-between;
		margin:0 30rpx;
		height: 90rpx;
		align-items: center;
	}
	.addressItem text.sexActive{
		background-color: #0BBBEF;
		color: #fff;
		border: none;
	}
</style>
