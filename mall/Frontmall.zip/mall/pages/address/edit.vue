<template>
	<view>
		<!-- 添加地址开始 -->
		<view class="username">
			<view class="itemTitle">
				收货人:
			</view>
			<input type="text" v-model="username" placeholder="收货人姓名">
		</view>
		<view class="addressItem">
			<view class="itemTitle">
			
			</view>
			<text :class="{sexActive:sex==1}" @click="sexChange(1)">先生</text>
			<text :class="{sexActive:sex==0}" @click="sexChange(0)">女士</text>
		</view>
		<view class="addressItem">
			<view class="itemTitle">
				电话号码:
			</view>
			<input type="text" v-model="telphone" placeholder="收货人电话号码">
		</view>
		<view class="addressItem">
			<view class="itemTitle">
			收货地址:
			</view>
			 <pickerAddress class="city" @change="change">{{city}}</pickerAddress>
		</view>
		<view class="addressBox">
			<view class="itemTitle">
				详细地址:
			</view>
			<textarea v-model="address" placeholder="请输入详细收货地址" />
		</view>
		<!-- 添加地址结束 -->
		
		<!-- 默认地址拦开始 -->
		<view class="defaults">
			<view class="itemTitle">默认地址:</view>
			<template v-if="defaultAddress==1">
				<switch checked="true" @change="changedefault" style="transform: scale(0.7);"></switch>
			</template>
			<template v-else>
				<switch @change="changedefault" style="transform: scale(0.7);"></switch>
			</template>
		</view>
		<!-- 默认地址拦结束 -->
		
		
		
		<!-- 按钮开始 -->
		<view class="saeAddress" @click="editAddress">保存收货地址</view>
		<!-- 按钮结束 -->
	</view>
</template>

<script>
	//导入插件
	 import pickerAddress from '../../componets/pickerAddress/pickerAddress.vue'
	export default {
		components:{
			pickerAddress
		},
		data() {
			return {
				 city: '请选择收货地址',
				 username:'',
				 telphone:'',
				 address:'',
				 defaultAddress:1,
				 sex:1,
				 aid:'',
				 backurl:''
			}
		},
		onLoad(option){
			this.getAddressInfo(option.id)
			this.aid = option.id
			this.backurl = option.backurl
		},
		methods: {
			//是否设置为默认地址
			changedefault(e){
				if(e.detail.value){
					this.defaultAddress = 1
				}else{
					this.defaultAddress = 0
				}
			},
			//性别切换
			sexChange(index){
				this.sex = index
			},
			//获取地址详细信息
			getAddressInfo(id){
				this.$request('member/getAddressInfo',{
					id:id
				})
				.then(res=>{
					console.log(res.data)
					this.city = res.data.city;
					this.username = res.data.username;
					this.telphone = res.data.telphone;
					this.address = res.data.address;
					this.defaultAddress = res.data.default;
					this.sex = res.data.sex;
				})
			},
			//编辑地址
			editAddress(){
				this.$request('member/addressEdit',{
					city:this.city,
					username:this.username,
					telphone:this.telphone,
					address:this.address,
					default:this.defaultAddress,
					sex:this.sex,
					id:this.aid
				})
				.then(res=>{
					if(this.backurl){
						uni.setStorageSync('addressId',this.aid);
						// uni.showToast({
						// 	title:"修改地址成功",
						// 	icon:"none"
						// })
						this.$href('../order/order',1)
					}else{
						this.$href('list',1)
						// uni.showToast({
						// 	title:"修改地址成功",
						// 	icon:"none"
						// })
					}
				})
			},
			//插件实现
			change(data) {
			        this.city = data.data.join('')
			        //console.log(data.data.join(''))
			    }
		}
	}
</script>

<style>
	.username {
		padding: 0 30rpx;
		line-height: 90rpx;
		display: flex;
		align-items: center;
	}
	.itemTitle {
		width: 140rpx;
		font-size: 28rpx;
	}
	.username input {
		border-bottom: 1rpx solid #E5E5E5;
		flex: 1;
		height: 90rpx;
	}
	.addressItem {
		padding: 0 30rpx;
		display: flex;
		height: 90rpx;
		align-items: center;
		border-bottom: 1rpx solid #E5E5E5;
	}
	.addressItem text {
		display: block;
		width: 80rpx;
		height: 45rpx;
		border: 1rpx solid #EEEEEE;
		margin-right: 10rpx;
		font-size: 24rpx;
		text-align: center;
		line-height: 45rpx;
		color: #999;
	}
	.addressBox {
		display: flex;
		border-bottom: 1rpx solid #E5E5E5;
		height: 180rpx;
		padding: 0 0 0rpx 30rpx;
		line-height: 180rpx;
	}
	textarea {
		/* border: 1rpx solid red; */
		padding-left: 20rpx;
		height: 100%;
	}
	.addressBox .itemTitle {
		border-right: 1rpx solid #E5E5E5;
	}
	.saeAddress {
		width: 600rpx;
		height: 80rpx;
		background-color: #0BBBEF;
		color: #fff;
		font-size: 30rpx;
		font-weight: 700;
		margin: 80rpx auto;
		text-align: center;
		line-height: 80rpx;
		border-radius: 80rpx;
	}
	.city {
		font-size: 28rpx;
		color: #000;
	}
	.defaults {
		display: flex;
		justify-content: space-between;
		margin:0 30rpx;
		height: 90rpx;
		align-items: center;
	}
	.addressItem text.sexActive{
		background-color: #0BBBEF;
		color: #fff;
		border: none;
	}
</style>
