<template>
	<view v-if="show">
		<!-- 地址列表开始 -->
		<view  class="addressList"  v-if="addressList&&addressList.length>0">
			<uni-swipe-action>
				<uni-swipe-action-item :right-options="options"
				  @click="onClick($event,index,item.id)"
				  v-for="(item,index) in addressList"
				  :key="index"
				  >
				   <view class="addressItem" @click="selectAddress(item.id)">
					 <view class="addressMain">
						<text class="username">{{item.username}}</text>
						<text class="telphone">{{item.telphone}}</text>
						<text class="default" v-if="item.default==1">默认</text>
					 </view>
					<view class="addressInfo">
						{{item.city}}{{item.address}}
					 </view>
				   </view>
				</uni-swipe-action-item>
			</uni-swipe-action>
		<!-- 展位符防止地址过多被遮挡 -->
		<view style="height:90rpx"></view>
		<!-- 底部添加新地址按钮 -->
		<view class="addBtn" @click="addAddress">添加新地址</view>
	</view>
		<!-- 列表为空时显示 -->
		<view class="empty" v-else>
			<image src="../../static/default/address.png" mode=""></image>
			<text>您还没有添加收货地址哟～</text>
		</view>
</view>
</template>

<script>
	import uniSwipeAction from '../../componets/uni-swipe-action/uni-swipe-action.vue'
	import uniSwipeActionItem from '../../componets/uni-swipe-action-item/uni-swipe-action-item.vue'
	export default {
		components:{
			uniSwipeAction,
			uniSwipeActionItem
		},
		data(){
			return{
				show:false,
				options:[
				         {
							text: '编辑',
				            style: {
							 backgroundColor: '#007aff',
				            }
				         }, {
				            text: '删除',
				            style: {
							 backgroundColor: '#dd524d',
				            }
				         }
						],
				addressList:[],//存放地址数据
				backurl:''
				}
		},
		onLoad(Option){
			this.getData();
			this.backurl = Option.backurl
		},
		methods:{
			//选择地址事件
			selectAddress(id){
				if(this.backurl==1){
					uni.setStorageSync('addressId',id)//重新设置地址id再根据新的地址id发请求更新地址
					uni.navigateTo({
						url:'../order/order'
					})
				}
			},
			//获取地址列表
			getData(){
				 this.$request('member/addressList')
				 .then(res=>{
					 this.addressList = res.data
					 this.show = true
					 console.log(res)
				 })
			 },
			 //删除&&编辑事件
			onClick(e,index,id){
				  if(e.content.text=='删除'){
					  uni.showModal({
					      title: '提示',
					      content: '确定要删除该地址吗？',
					      success: res=>{
					          if (res.confirm) {
								  //前端删除操作
					              this.addressList.splice(index,1)
								  //后端删除操作
								  this.$request('member/addressDel',{
									 id:id
								  })
								  .then(res=>{
									  console.log(res)
								  })
					          } else if (res.cancel) {
					              console.log('用户点击取消');
					          }
					      }
					  });
				  }
				  if(e.content.text=='编辑'){
				  	if(this.backurl==1){
						uni.navigateTo({
							url:'./edit?id='+id+'&backurl='+this.backurl//如果有携带backurl这个参数则携带这个参数再跳转到编辑页面
						})
					}else{
						uni.navigateTo({
							url:'./edit?id='+id//否则直接跳转
						})
					}
				  }
			    },
			//添加地址
			addAddress(){
				if(this.backurl==1){
					this.$href('add?backurl='+this.backurl,1)//同上
				}else{
					this.$href('add',1)//同上
				}
			}
		}
	}
</script>

<style>
	.empty image{
		width: 330rpx;
		height: 210rpx;
		display: block;
		margin: 200rpx auto 0;
	}
	.empty text {
			font-size: 24rpx;
			display: block;
			line-height: 80rpx;
			text-align: center;
			color: #999;
		}
	.addressItem {
		padding: 0 35rpx;
		border-bottom: 1rpx solid #E5E5E5;
	}
	.addressMain {
		line-height: 40rpx;
		font-size: 30rpx;
		padding-top: 30rpx;
		margin-bottom: 7rpx;
		font-weight: 700;
		letter-spacing: 2rpx;
	}
	.addressMain .telphone {
		padding: 0 20rpx 0 10rpx;
	}
	.addressInfo {
		line-height: 36rpx;
		font-size: 24rpx;
		color: #999;
		padding-bottom: 36rpx;
	}
	.default {
		background: #1fc8f2;
		color: #fff;
		padding: 0 10rpx;
		font-size: 20rpx;
	}
	.addBtn  {
		background-color: #0bbbef;
		color: #fff;
		position: fixed;
		left:0;
		bottom: 0;
		width: 100%;
		height: 90rpx;
		font-size: 30rpx;
		text-align: center;
		line-height: 90rpx;
		font-weight: 700;
	}
</style>
