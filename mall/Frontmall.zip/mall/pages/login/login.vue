<template>
	<view>
		<view class="logo">
			<image src="../../static/OIP.jpeg" mode=""></image>
		</view>
		<view class="formList">
			<view class="formItem">
				<input  v-model="telphone" placeholder="请输入手机号"/>
			</view>
			<view class="formItem">
				<input type="password" v-model="password"  placeholder="请输入密码"/>
			</view>
		</view>
		<view class="loginBtn" @click="login">
			登录
		</view>
		<view class="loginNav">
			<navigator url="#">忘记密码</navigator>
			<text>|</text>
			<navigator url="#" class="loginRegister">注册账号</navigator>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				telphone:'',
				password:'',
				backurl:''
			}
		},
		onLoad(Option){
			this.backurl = Option.backurl
		},
		methods: {
			login(){
				//前端数据验证，只有当手机格式正确的时候才向后端发请求，手机格式不正确的时候不用向后端发请求
				//手机格式验证
			/***********************************************************************/
				// if(!(/^1[3456789]\d{9}$/.test(this.telphone))){
				// 		uni.showToast({
				// 			title:"手机格式有误",
				// 			icon:"none"
				// 		})
				// 	    return false; 
				// 	}
				
				//密码长度验证
				// if(this.password.length<6){
				// 	uni.showToast({
				// 		title:"密码长度不能小于六位",
				// 		icon:"none"
				// 	})
				// 	return false;
				// }
			/***********************************************************************/
			//验证手机格式是否正确
			if(!this.check.telphone(this.telphone)){return;}
			//验证密码是否正确
			if(!this.check.password(this.password)){return;}
			//都正确那就登陆成功
				uni.request({
					url:this.apiUrl+'index/login',
					method:"POST",
					data:{
						telphone:this.telphone,
						password:this.password
					},
					success:(res) => {
						if(res.data.code==0){
							uni.showToast({
								title:res.data.msg,
								icon:"none"
							})
						}else{
							uni.showToast({
								title:res.data.msg,
								icon:"none"
							})
							uni.setStorageSync('token',res.data.data.token)
							//登录成功1、若有参数backurl则跳回backurl;2、若无或未空则跳回member页面
							if(this.backurl==""||!this.backurl){
									uni.switchTab({
									url:'../member/member'
								})
							}else{
								if(this.backurl==1){
									uni.navigateBack({
										delta:1
									})
								}else{
									uni.navigateTo({
										url:this.backurl
									})
								}
							}
						}
					}
				})
			}
		}
	}
</script>

<style>
	.logo {
		width: 250rpx;
		height: 250rpx;
		margin: 150rpx auto 15rpx;
		
	}
	.logo image {
		width: 100%;
		height: 100%;
	}
	.formItem {
		height: 74rpx;
		padding-top: 36rpx;
		border-bottom: 1rpx solid #E5E5E5;
		margin: 0 100rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.formItem input {
		font-size: 28rpx;
	}
	.getCode {
		width: 180rpx;
		height: 60rpx;
		color: #666;
		background-color: #F7F7F7;
		line-height: 60rpx;
		font-size: 24rpx;
		border: none;
		text-align: center;
	}
	.getCode.ActiveSelect {
			background-color: #00BFFF;
			color: #fff;
	}
	.loginBtn {
		margin: 60rpx 100rpx 0;
		height: 90rpx;
		background-color: #00BFFF;
		color: #fff;
		line-height: 90rpx;
		font-size: 30rpx;
		font-weight: 700;
		text-align: center;
		border-radius: 5rpx;
	}
	.loginNav {
		display: flex;
		justify-content: center;
		align-items: center;
		height: 120rpx;
		font-size: 24rpx;
	}
	.loginNav text {
		padding:0 20rpx
	}
	.loginRegister{
		color: #00BFFF;
	}
		
	
</style>
