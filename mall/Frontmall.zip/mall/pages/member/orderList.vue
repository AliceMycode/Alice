<template>
	<view class="">
		<!-- 订单状态拦 -->
		<view class="statusTab">
			<view class="tabItem" :class="{tabItemActive:statusVal==0}" @click="statusHref(0)">
				全部订单
			</view>
			<view class="tabItem" :class="{tabItemActive:statusVal==1}" @click="statusHref(1)">
				待付款
			</view>
			<view class="tabItem" :class="{tabItemActive:statusVal==2}" @click="statusHref(2)">
				待收货
			</view>
			<view class="tabItem" :class="{tabItemActive:statusVal==4}" @click="statusHref(4)">
				待评价
			</view>
		</view>
		<!-- 占位符把盒子撑开 -->
		<view class="empty" style="height: 70rpx;"></view>
		<!-- 商品列表开始 -->
		<scroll-view class="orderList" scroll-y="true" @scrolltolower="lower" lower-threshold="30">
			<view class="orderItem" @click="orderHref" v-for="(item,index) in orderList" :key="index">
				<view class="orderStatus">
					订单日期：{{item.time}}
					<!-- 0表示全部订单1表示待付款2表示已付款待发货3表示已发货待收货4表示已收货待评价5表示已完成6表示已取消 -->
					<text v-if="item.status==1">待付款</text>
					<text v-if="item.status==2">已付款待发货</text>
					<text v-if="item.status==3">已发货待收货</text>
					<text v-if="item.status==4">已收货待评价</text>
					<text v-if="item.status==5">已完成</text>
					<text v-if="item.status==6">已取消</text>
				</view>
				<!-- 商品列表 -->
				<view class="orderShopList">
					<view class="shopListItem" v-for="(item1,index1) in item.shop" :key="index1">
						<image :src="imgUrl+item1.mainimage" mode=""></image>
						<view class="shopListContent">
							<view class="contentTitle">
								{{item1.title}}
							</view>
							<view class="contentAttr">
								{{item1.attr_0}}{{item1.attr_1}}
							</view>
							<view class="contentPrice">
								¥ {{item1.price}} <text>x{{item1.num}}</text>
							</view>
						</view>
					</view>
				</view>
				<!-- 合计、运费 -->
				<view class="totalBox">
					共 {{item.allnum}} 件商品 合计： <text>¥ {{item.allprice}}</text>（运费：¥{{item.logisticsprice}}）
				</view>
			</view>
			<!-- 加载更多 -->
			<loading :status="status"></loading>
		</scroll-view>
	</view>
</template>

<script>
	import loading from '@/componets/uni-load-more.vue'
	export default {
		components:{
			loading
		},
		data(){
			return{
				orderList:[],//存放商品列表
				page:1,//默认加载一页
				allpage:0,//所有分页
				status:"loading",//加载更多
				statusVal:0//订单状态默认为0全部订单
			}
		},
		onLoad(option){
			if(option.status){
				this.statusVal = option.status
			}else{
				this.statusVal = 0;
			}
			this.getData();
		},
		
		//页面滚动到底部就加载下一页数据
		// onReachBottom(){
		// 	if(this.page>=this.allpage){
		// 		this.status = "noMore";
		// 		return;
		// 	}else{
		// 		this.page++;
		// 	}
		// 	this.getData();
		// },
		
		methods:{
			//点击导航栏切换页面事件
			statusHref(index){
				this.$href("orderList?status="+index,1);
			},
			//滚动条距离底部20rpx触发改事件
			lower(){
				if(this.page>=this.allpage){
					this.status = "noMore";
					return;
				}else{
					this.status = "loading";
				}
				this.page++;
				this.getData();
				console.log("我来了")
			},
			//点击订单跳转到订单详情页面
			orderHref(){
				this.$href("/pages/member/orderDetail",1);
			},
			//获取商品列表
			getData(){
				this.$request("member/orderlist",{
					status:this.statusVal,
					page:this.page
				}).then(res=>{
					if(res.data.last_page==res.data.current_page){
						this.status = "noMore"
					}
					this.allpage = res.data.last_page;
					this.orderList  = this.orderList.concat(res.data.data);
					console.log(res.data);
					console.log(this.orderList);
				})
			}
		}
	}
</script>

<style>
	.statusTab{
		height: 70rpx;
		display: flex;
		line-height: 70rpx;
		position: fixed;
		width: 100%;
		background-color: #fff;
		z-index: 5;
	}
	.tabItem {
		font-size: 28rpx;
		width: 25%;
		text-align: center;
		color: #999;
	}
	.tabItemActive {
		color: #00C3F5;
		font-weight: bold;
	}
	.orderItem {
		border-top: 20rpx solid #F4F4F4;
	}
	.orderStatus {
		height: 80rpx;
		display: flex;
		padding: 0 20rpx;
		justify-content: space-between;
		font-size: 28rpx;
		border-bottom: 1rpx solid #e8e8e8;
		align-items: center;
	}
	.orderStatus text {
		color: #00C3F5;
	}
	.orderShopList .shopListItem:nth-of-type(1){border:none}
	.orderList {
		position: absolute;
		bottom: 0;
		top: 70rpx;
		width: 100%;
	}
	.shopListItem {
		display: flex;
		margin: 0 20rpx;
		border-top: 1rpx solid #E5E5E5;
	}
	.shopListItem image {
		width: 200rpx;
		height: 200rpx;
		margin: 10rpx 0;
	}
	.shopListContent {
		flex: 1;
		margin-top: 10rpx;
	}
	.shopListContent .contentTitle {
		font-size: 28rpx;
		line-height: 40rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp:2;
		-webkit-box-orient:vertical;
	}
	.shopListContent .contentAttr{
		font-size: 24rpx;
		line-height: 40rpx;
		color: #999;
	}
	.shopListContent .contentPrice {
		line-height: 80rpx;
		font-size: 30rpx;
		color: red;
		font-weight: bold;
		display: flex;
		justify-content: space-between;
	}
	.shopListContent .contentPrice  text {
		color: #999;
	}
	.totalBox {
		font-size: 28rpx;
		line-height: 80rpx;
		color: #999;
		padding: 0 20rpx;
		border-top: 1rpx solid #E5E5E5;
		text-align: right;
	}
	.totalBox text {
		color: #00C3F5;
		font-weight: bold;
	}
</style>
