<template>
	<view class="container">
		<!-- 订单状态 -->
		<view class="orderDetailTop">
			订单状态：<text>待付款</text>
		</view>
		<!-- 订单地址 -->
		<view class="orderAddress">
			<view class="addressIcon">
				<i class="iconfont">&#xe622;</i>
			</view>
			<view class="addressContent">
				<view class="addressTitle">
					收货人：邱志许（17817129178）
				</view>
				<view class="addressInfo">
					广东省江门市蓬江区迎宾大道99号五邑大学
					广东省江门市蓬江区迎宾大道99号五邑大学
				</view>
			</view>
			<!-- 边界 -->
			<view class="addressLine"></view>
		</view>
		<!-- 商品列表 -->
		<view class="orderShopList">
			<view class="shopListItem">
				<image src="../../static/image/p1.png" mode=""></image>
				<view class="shopListContent">
					<view class="contentTitle">
						魅族 16s Pro高通骁龙 855 Plus  | 索尼 4800W 像素超广角 AI 三摄
						魅族 16s Pro高通骁龙 855 Plus  | 索尼 4800W 像素超广角 AI 三摄
					</view>
					<view class="contentAttr">
						魅族 16s Pro
					</view>
					<view class="contentPrice">
						¥ 2999.99 <text>x1</text>
					</view>
				</view>
			</view>
			<view class="shopListItem">
				<image src="../../static/image/p1.png" mode=""></image>
				<view class="shopListContent">
					<view class="contentTitle">
						魅族 16s Pro高通骁龙 855 Plus  | 索尼 4800W 像素超广角 AI 三摄
						魅族 16s Pro高通骁龙 855 Plus  | 索尼 4800W 像素超广角 AI 三摄
					</view>
					<view class="contentAttr">
						魅族 16s Pro
					</view>
					<view class="contentPrice">
						¥ 2999.99 <text>x1</text>
					</view>
				</view>
			</view>
		</view>
		<!-- 订单信息 -->
		<view class="orderInfoList">
			<view class="orderItem">
				应付金额<text>¥2999.99</text>
			</view>
			<view class="orderItem">
				配送方式<text>顺丰</text>
			</view>
			<view class="orderItem messageBox">
				请留言
			</view>
			<view class="orderItem">
				总计<text>共2件商品合计：¥2999.99</text>
			</view>
			<view class="orderItem">
				订单编号<text>3621783972173021</text>
			</view>
			<view class="orderItem">
				下单时间<text>2022-03-01 14:20:30</text>
			</view>
			<view class="orderItem">
				支付方式<text>微信支付</text>
			</view>
			<view class="orderItem">
				支付时间<text>2022-03-01 14:20:30</text>
			</view>
		</view>
		<!-- 底部支付、取消按钮 -->
		<view class="detailBox">
			<view class="pay">去支付</view>
			<view class="cancel">取消</view>
		</view>
		<!-- 占位符把盒子撑开 -->
		<view class="empty" style="height:100rpx"></view>
	</view>
</template>

<script>
</script>

<style>
	.orderDetailTop {
		font-size: 28rpx;
		height: 100rpx;
		line-height: 100rpx;
		border-top: 1rpx solid #E5E5E5;
		padding: 0 30rpx;
		border-bottom: 20rpx solid #f4f4f4;
	}
	.orderDetailTop text {
		color: #00c2f5;
	}
	.orderAddress {
		display: flex;
		padding: 0 30rpx;
		position: relative;
		height: 200rpx;
		border-bottom: 20rpx solid #F4F4F4;
	}
	.addressIcon {
		width: 100rpx;
		display: flex;
		justify-content: center;
		line-height:95rpx;
		font-size: 36rpx;
		color: #999;
	}
	.addressContent {
		flex: 1;
	}
	.addressTitle {
		font-size: 28rpx;
		margin-top: 10rpx;
		line-height: 68rpx;
	}
	.addressInfo {
		font-size: 24rpx;
		line-height: 34rpx;
		color: #999;
	}
	/* 边界样式 */
	.addressLine {
	    height: 4px;
	    background-image: -webkit-linear-gradient(315deg,#82c9ff 8px,transparent 0,transparent 16px,#ff8282 0,#ff8282 32px,transparent 0,transparent 0,transparent 40px,#82c9ff 0,#82c9ff);
	    background-image: linear-gradient(135deg,#82c9ff 8px,transparent 0,transparent 16px,#ff8282 0,#ff8282 32px,transparent 0,transparent 0,transparent 40px,#82c9ff 0,#82c9ff);
	    background-color: #fff;
	    background-size: 68px 4px;
	    position: absolute;
	    bottom: 0;
	    width: 100%;
	}
	.orderShopList .shopListItem:nth-of-type(1){border:none}
	.shopListItem {
		display: flex;
		margin: 0 20rpx;
		border-top: 1rpx solid #E5E5E5;
	}
	.shopListItem image {
		width: 200rpx;
		height: 200rpx;
		margin: 10rpx 0;
	}
	.shopListContent {
		flex: 1;
		margin-top: 10rpx;
	}
	.shopListContent .contentTitle {
		font-size: 28rpx;
		line-height: 40rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp:2;
		-webkit-box-orient:vertical;
	}
	.shopListContent .contentAttr{
		font-size: 24rpx;
		line-height: 40rpx;
		color: #999;
	}
	.shopListContent .contentPrice {
		line-height: 80rpx;
		font-size: 30rpx;
		color: red;
		font-weight: bold;
		display: flex;
		justify-content: space-between;
	}
	.shopListContent .contentPrice  text {
		color: #999;
	}
	.orderItem {
		margin: 0 20rpx;
		font-size: 28rpx;
		display: flex;
		justify-content: space-between;
		line-height: 80rpx;
	}
	.orderItem text {
		color: #999;
	}
	.orderInfoList {
		padding: 20rpx 0;
		border-top: 1rpx solid #E5E5E5;
	}
	.messageBox {
		background-color: #E5E5E5;
		color: #999;
		border-radius: 80rpx;
		text-indent: 30rpx;
	}
	.detailBox {
		border-top: 1rpx solid #E5E5E5;
		display: flex;
		justify-content: right;
		height: 100rpx;
		align-items: center;
		position: fixed;
		bottom: 0;
		width: 100%;
		background-color: #fff;
		right: 20rpx;
	}
	.detailBox .pay {
		width: 175rpx;
		height: 70rpx;
		background-color: #00C3F5;
		line-height: 70rpx;
		font-size: 24;
		font-weight: bold;
		color: #fff;
		text-align: center;
		border-radius: 50rpx;
		margin-right: 20rpx;
	}
	.detailBox .cancel {
		width: 175rpx;
		height: 70rpx;
		background-color: #F4F4F4;
		line-height: 70rpx;
		font-size: 24;
		font-weight: bold;
		color: #666;
		text-align: center;
		border-radius: 50rpx;
	}
</style>
