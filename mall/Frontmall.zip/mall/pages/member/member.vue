<template>
	<view>
		<!-- 顶部登陆信息 -->
		<view class="member-top">
			<!-- 用户没有上传头像默认显示空白头像 -->
			<template v-if="!member.image">
				<image src="../../static/image/empty-tx.png" mode="" class="member-tx"></image>
			</template>
			<!-- 有则上传自己的图片 -->
			<template v-else>
				<image :src="member.image" mode="" class="member-tx"></image>
			</template>
			<view class="userInfo">
				<view class="loginReg" v-if="$store.state.isLogin==0">
					<navigator url="../login/login" hover-class="none">登录/注册</navigator>
					</view>
				<view class="loginInfo" v-else>
					<!-- 用户没有设置昵称默认显示冷冽 -->
					<template v-if="!member.nickname">
						<text class="username">冷冽</text>
					</template>
					<!-- 有则显示用户自己的昵称 -->
					<template v-else>
						<text class="username">{{member.nickname}}</text>
					</template>
					<text class="nickname">{{member.telphone}}</text>
				</view>
			</view>
			<view class="ewm">
				<image src="../../static/image/ewm.png" mode=""></image>
			</view>
			<view class="memberIcon">
				<i class="iconfont">&#xe612;</i>
				<i class="iconfont">&#xe614;</i>
			</view>
		</view>
		<!-- 订单状态 -->
		<view class="orderStatus">
			<view class="orderItem" @click="statusHref(1)"><!-- 0表示全部订单1表示待付款2表示已付款待发货3表示已发货待收货4表示已收货待评价5表示已完成6表示已取消 -->
				<image src="../../static/image/member-icon1.png" mode=""></image>
				<text>待付款</text>
			</view>
			<view class="orderItem" @click="statusHref(2)">
				<image src="../../static/image/member-icon2.png" mode=""></image>
				<text>待收货</text>
			</view>
			<view class="orderItem" @click="statusHref(4)">
				<image src="../../static/image/member-icon3.png" mode=""></image>
				<text>待评价</text>
			</view>
			<view class="orderItem" @click="statusHref(0)">
				<image src="../../static/image/member-icon4.png" mode=""></image>
				<text>全部订单</text>
			</view>
		</view>
		<!-- 分割线 -->
		<view class="splitLine"></view>
		<!-- 菜单栏 -->
		<view class="menuList">
			<!-- 不能用标签进行跳转，否则就么办法进行逻辑判断 -->
			<!-- <navigator url="../address/list" hover-class="none"> -->
			<view class="menuItem" @click="href('../address/list')">
				<image src="../../static/image/member-menu1.png" mode=""></image>
				<text>收货地址</text>
			</view>
			<!-- </navigator> -->
			<view class="menuItem">
				<image src="../../static/image/member-menu2.png" mode=""></image>
				<text>在线客服</text>
			</view>
			<view class="menuItem">
				<image src="../../static/image/member-menu3.png" mode=""></image>
				<text>邀请有礼</text>
			</view>
			<view class="menuItem">
				<image src="../../static/image/member-menu5.png" mode=""></image>
				<text>关于我们</text>
			</view>
		</view>
		<!-- 退出登录按钮 -->
		<view class="loginout" @click="loginout" v-if="$store.state.isLogin">
			退出登录
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				member:[]//存放用户信息
			}
		},
		onLoad(){
			//this.getData();
		},
		onShow(){
			this.getData();
		},
		methods: {
			//订单状态栏点击事件
			statusHref(index){
				this.$href("/pages/member/orderList?status="+index,1);
			},
			//跳转到地址列表页面
			href(url){
				this.$href(url,1);
			},
			//获取用户信息
			getData(){
				this.$request('member/index')
				.then(res=>{
					//已登陆
					console.log(res)
					if(res.code==1){
						this.$store.commit('login')
						this.member=res.data;
					}
				})
			},
			//退出登陆
			loginout(){
				this.$store.commit('loginout')
			}
		}
	}
</script>

<style>
	.member-top {
		height: 336rpx;
		background: url(../../static/image/member-top.png) no-repeat;
		 background-size: 100% 336rpx;
		 position: relative;
	}
	.member-tx {
		width: 110rpx;
		height: 110rpx;
		position: absolute;
		border-radius: 50%;
		top: 165rpx;
		left: 30rpx;
	}
	.loginReg {
		width: 160rpx;
		height: 45rpx;
		color: #fff;
		border: 1rpx solid #fff;
		font-size: 28rpx;
		text-align: center;
		line-height: 45rpx;
		position: absolute;
		top: 190rpx;
		left: 160rpx
	}
	.loginInfo{
		position: absolute;
		top: 180rpx;
		left: 160rpx
	}
	.loginInfo text.username {
		height: 42rpx;
		line-height: 42rpx;
		font-size: 30rpx;
		color: #fff;
		display: block;
	}
	.loginInfo text.nickname{
		height: 38rpx;
		line-height: 38rpx;
		font-size: 24rpx;
		color: #fff;
		display: block;
	}
	.ewm {
		width: 35rpx;
		height: 35rpx;
		position: absolute;
		top: 200rpx;
		right: 30rpx;
	}
	.ewm image {
		width: 35rpx;
		height: 35rpx;
	}
	.memberIcon {
		position: absolute;
		right: 30rpx;
		top: 50rpx;
		color: #fff;
	}
	.memberIcon i {
		margin-left: 30rpx
	}
	.orderStatus {
		display: flex;
	}
	.orderItem {
		width:25%;
	}
	.orderItem image {
		width: 70rpx;
		height: 56rpx;
		display: block;
		margin: 20rpx auto 0;
	}
	.orderItem text {
		display: block;
		font-size: 30rpx;
		line-height: 80rpx;
		text-align: center;
		padding-bottom: 10rpx;
	}
	.splitLine {
		height: 20rpx;
		width: 100%;
		background-color: #F5F5F5;
	}
	.menuItem {
		height: 90rpx;
		margin: 0 30rpx;
		border-bottom: 1rpx solid #e5e5e5;
		font-size: 28rpx;
		display: flex;
		align-items: center;
		background: url(../../static/image/more.png) no-repeat;
		background-size: 26rpx 26rpx;
		background-position: right center;
	}
	.menuItem image {
		width: 30rpx;
		height: 30rpx;
		margin-right: 25rpx;
	}
	.menuItem:nth-child(4){
		border-bottom: none;
	}
	.loginout {
		margin: 30rpx;
		heigth: 85rpx;
		line-height: 85rpx;
		border: 1rpx solid #e5e5e5;
		font-size: 30rpx;
		text-align: center;
		background-color: #00C3F5;
		color: #fff;
		letter-spacing: 2rpx;
		font-weight: 700;
	}
</style>
