<template>
	<view>
		<!-- 轮播图 -->
		<!-- class="detailSwiper" indicator-active-color="#00beff" :indicator-dots="true" :autoplay="true"
			:interval="3000" :duration="1000" :circular="true" indicator-color="#7d7c82" -->
		<!-- <swiper class="detailSwiper" indicator-active-color="#00beff" :indicator-dots="true" :autoplay="true"
			:interval="3000" :duration="1000" :circular="true" indicator-color="#7d7c82">
			<swiper-item>
				<view class="swiper-item">
					<image src="../../static/image/dimg1.jpg" mode=""></image>
				</view>
			</swiper-item>
			<swiper-item>
				<view class="swiper-item">
					<image src="../../static/image/dimg2.jpg" mode=""></image>
				</view>
			</swiper-item>
			<swiper-item>
				<view class="swiper-item">
					<image src="../../static/image/dimg3.jpg" mode=""></image>
				</view>
			</swiper-item>
			<swiper-item>
				<view class="swiper-item">
					<image src="../../static/image/dimg4.jpg" mode=""></image>
				</view>
			</swiper-item>
		</swiper> -->
		<!--注意：样式绑定不需要加冒号： -->
		<detailSwiper :swiper="detail.image" swiperHeight="525rpx" swiperActive="#00beff" width="470rpx" height="470rpx"></detailSwiper>
		<!-- 商品信息 -->
		<view class="shop-Info">
			<view class="shop-title">
				<label v-if="detail.tag==1">新品</label>
				<label v-else-if="detail.tag==2">热销</label>
				<label v-else>促销</label>
				{{detail.title}}
			</view>
			<view class="shop-summary">
				{{detail.summary}}
			</view>
			<view class="shop-price-sale">
				<view class="shop-price">
					<text> ¥ </text>{{detail.price}}<label> ¥ {{detail.market_price}}</label>
				</view>
				<view class="shop-sale">
					月销售量：{{detail.sale}}件
				</view>
			</view>
			<view class="shop-assure" @click="showService">
				<view class="shop-assure-item" v-for="(item,index) in detail.servicelist" :key="index">
					<template v-if="index<2">
						<i class="iconfont">&#xe60d;</i>{{item.title}}
					</template>
				</view>
				<!-- <view class="shop-assure-item">
					<i class="iconfont">&#xe60d;</i>七天无理由退货（激活不支持）
				</view> -->
				<view class="shop-assure-more">
					<i class="iconfont">&#xe60b;</i>更多
				</view>
			</view>
		</view>
		<!-- 商品详情 -->
		<view class="shopAttr" @click="attrShow(1)">
			<label>规格</label><text>{{$store.state.attrTxt}}</text>
			<view><i class="iconfont">&#xe60b;</i>更多</view>
		</view>
		<view class="shopTab">
			<view class="shopTabItem" @click="tabChange(0)" :class="{tabActive:tab==0}">
				图文详情
			</view>
			<view class="shopTabItem" @click="tabChange(1)" :class="{tabActive:tab==1}">
				规格参数
			</view>
		</view>
		<!-- 富文本解析 -->
		<view class="content" v-if="tab==0">
		<!-- 	<image src="../../static/image/d1.jpg" mode="widthFix"></image>
			<image src="../../static/image/d2.jpg" mode="widthFix"></image>
			<image src="../../static/image/d3.jpg" mode="widthFix"></image> -->
			<!-- www.mall.com默认为HTTP发请求 -->
			<parse :content="detail.content" :imageProp="{'domain':'www.mall.com'}"></parse>
		</view>
		<view class="shopSpecs"v-else>
			<view class="specsTitle">
				基础信息
			</view>
			<view class="specsContent">
				<view class="specsContentLeft">
					品牌
				</view>
				<view class="specsContentRight">
					魅族
				</view>
			</view>
			<view class="specsContent" v-for="(item,index) in detail.spec" :key="index">
				<view class="specsContentLeft">
					{{item.specname}}
				</view>
				<view class="specsContentRight">
					{{item.specvalue}}
				</view>
			</view>
		</view>
		<!-- 底部信息 -->
		<view style="height: 110rpx;width: 100%;"></view>
		<view class="detailBottom">
			<view class="bottomItem">
				<view class="bottomItemIndex">
					<navigator url="../index/index" hover-class="none" open-type="switchTab">
						<image src="../../static/tabbar1.png" mode=""></image>
						<text>首页</text>
					</navigator>
				</view>
				<view class="bottomItemCart">
					<navigator url="../cart/cart" open-type="switchTab">
						<image src="../../static/tabbar3.png" mode=""></image>
						<text>购物车</text>
					</navigator>
					</view>
				</view>
				<view class="bottomButton cartButton" @click="attrShow(2)">
					加入购物车
				</view>
				<view class="bottomButton buyBooton" @click="attrShow(1)">
					立即购买
				</view>
			</view>
		<!-- 弹窗服务 -->
		<detailService :content="detail.servicelist" v-if="serviceFlag" @closeItem="closeService"></detailService>
		<shopAttr v-if="attrFlag" @closeEvent="closeAttr"
		:image = "detail.mainimage"
		:attr = "detail.attr"
		:price = "detail.price"
		:checkAttr = "detail.checkAttr"
		:type="type"
		></shopAttr>
		</view>
</template>
<!-- 
1、子组件向父组件传递数据：子组件通过触发事件的方式向父组件传递数据，而父组件在相应标签通过监听相应事件的方式接受子组件传来的数据； 
2、父组件向子组件传递数据：父页面在对应标签上通过自定义属性的方式向子组件传递数据，而子组件通过props来接受数据
 -->
<script>
	import detailService from '../../componets/detailService.vue'
	import shopAttr from '../../componets/shopAttr.vue'
	import detailSwiper from '../../componets/MyIndexSwiper.vue'
	import parse from '../../componets/gaoyia-parse/parse.vue'
	export default {
		data() {
			return {
				tab:0,
				serviceFlag:false,//服务弹窗显示隐藏
				attrFlag:false,//商品属性弹窗显示隐藏
				detail:[],//商品详情页数据
				type:1//商品属性页底部立即购买个加入购物车的切换2表示购物车1表示立即购买

			}
		},
		onLoad(option){
			this.getData(option.id);
		},
		components:{
			detailService,
			shopAttr,
			detailSwiper,
			parse
		},
		beforeDestroy(){
			this.$store.commit('defaultAttr')
		},
		methods: {
			//图文详情与规格参数切换显示
			tabChange(index){
				this.tab = index;
			},
			//显示服务弹窗
			showService(){
				this.serviceFlag = true;
			},
			//关闭服务弹窗
			closeService(){
				this.serviceFlag = false ; 
			},
			//显示属性弹窗
			attrShow(type){
				this.type = type
				this.attrFlag = true;
			},
			//关闭属性弹窗
			closeAttr(){
				this.attrFlag = false;
			},
			//获取商品数据
			getData(id){
				uni.request({
					// 提取公共路径
					url:this.apiUrl+'index/detail/id/'+id,
					success:(res)=>{
						var data  = res.data.data;
						this.detail = data;
						//每个商品的属性
						console.log(data)
					}
				})
			}
		
		}
	}
</script>

<style>
	.detailSwiper {
		width: 100%;
		height: 525rpx;
	}

	.detailSwiper image {
		/* 已经通过父子传输数据的方式将图片的宽、和高传给子组件了所以这里的宽和高已经不起作用来了 */
		/* width: 470rpx;
		height: 470rpx; */
		display: block;
		margin: 0 auto;
	}

	.shop-Info {
		padding: 0 30rpx;
		border-top: 1rpx solid #e9e9e9;
	}

	.shop-title {
		line-height: 40rpx;
		font-size: 28rpx;
		color: #000;
		padding-top: 24rpx;
	}

	.shop-title label {
		display: block;
		width: 64rpx;
		height: 40rpx;
		color: #fff;
		background-color: #18bef1;
		float: left;
		text-align: center;
		margin-right: 10rpx;
	}

	.shop-summary {
		color: #9a9a9a;
		font-size: 24rpx;
		line-height: 35rpx;
		padding-top: 10rpx;
	}

	.shop-price-sale {
		line-height: 83rpx;
		font-size: 28rpx;
		display: flex;
		justify-content: space-between;
		height: 83rpx;
		color: #999;
		border-bottom: 1rpx solid #e9e9e9;
	}

	.shop-price text {
		font-size: 36rpx;
		color: #f0415f;
		margin-right: 7rpx;
	}

	.shop-price {
		color: #f0415f;
		font-size: 45rpx;
	}

	.shop-price label {
		margin-left: 10rpx;
		font-size: 28rpx;
		color: #999;
		text-decoration: line-through;
	}
	.shop-assure {
		font-size: 24rpx;
		color: #999;
		height: 80rpx;
		line-height: 80rpx;
		/* overflow: hidden; */
	}
	.shop-assure-item i {
		font-size: 30rpx;
		color: #00c3f5;
		margin-right: 10rpx;
	}
	.shop-assure-item  {
		float: left;
		margin-right: 20rpx;
	}
	.shop-assure-more {
		float: right;
	}
	.shopAttr view {
		float: right;
		font-size: 24rpx;
		color: #999;
	}
	.shopAttr {
		height: 90rpx;
		padding: 0 30rpx;
		font-size: 28rpx;
		color: #999;
		border-top: 20rpx solid #f7f7f7;
		border-bottom: 20rpx solid #f7f7f7;
		line-height: 90rpx;
	}
	.shopAttr text {
		color: #000;
		margin-left: 24rpx;
	}
	.shopTab {
		height: 80rpx;
		display: flex;
		border-bottom: 1rpx solid #e5e5e5;
	}
	.shopTabItem {
		width: 50%;
		line-height: 80rpx;
		text-align: center;
		font-size: 28rpx;
		font-weight: border;
	}
	.shopTabItem.tabActive {
		color: #00c3f5;
	}
	.specsTitle {
		line-height: 75rpx;
		height: 75rpx;
		background-color: #f7f7f7;
		text-indent: 30rpx;
		color: #000;
		font-size: 30rpx;
	}
	.shopSpecs {
		margin: 20rpx 30rpx;
		border-left: 1rpx solid #e9e9e9;
	}
	.specsContent {
		display: flex;
		line-height: 80rpx;
		border-bottom: 1rpx solid #e9e9e9;
	}
	.specsContentLeft {
		width: 230rpx;
		text-align: center;
		font-size: 30rpx;
		color: #999;
	}
	.specsContentRight {
		flex: 1;
		text-align: center;
		font-size: 30rpx;
		color: #000;
		border-left: 1rpx solid #e9e9e9;
	}
	.content image {
		width: 100%;
	}
	.detailBottom {
		width: 100%;
		height: 110rpx;
		position: fixed;
		bottom: 0;
		display: flex;
		background-color: #fff;
	}
	.bottomButton {
		width: 275rpx;
		font-size: 30rpx;
		height: 100%;
		color: #fff;
		line-height: 110rpx;
		font-weight: 700;
		letter-spacing: 2rpx;
	}
	.bottomItem {
		flex: 1;
		display: flex;
	}
	.cartButton {
		background-color: #0ebcef;
		text-align: center;
	}
	.buyBooton {
		background-color: #017cf1;
		text-align: center;
	}
	.bottomItemIndex,.bottomItemCart {
		width: 50%;
		text-align: center;
		margin-top: 10rpx;
	}
	.bottomItemIndex image,.bottomItemCart image {
		width: 40rpx;
		height: 40rpx;
		display: block;
		margin: 0 auto;
	}
	.bottomItemIndex text,.bottomItemCart text {
		font-size: 24rpx;
		color: #999;
		display: block;
		margin: 10rpx auto 0;
	}
	
</style>
